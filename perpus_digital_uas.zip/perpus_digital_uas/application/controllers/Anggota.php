<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Anggota extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();

        // Cek Login
        if (!$this->session->userdata('id_user'))
        {
            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-danger">
                    <strong>Perhatian!</strong><br>
                    Silakan login terlebih dahulu.
                </div>'
            );

            redirect('login');
        }

        // Hak Akses
        if (
            $this->session->userdata('id_role') != ROLE_ADMIN &&
            $this->session->userdata('id_role') != ROLE_PETUGAS
        )
        {
            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-danger">
                    <strong>Akses Ditolak!</strong><br>
                    Anda tidak memiliki hak akses ke halaman Anggota.
                </div>'
            );

            redirect('dashboard');
        }

        $this->load->model('Anggota_model');
        $this->load->library('pagination');
    }

    public function index()
{
    $data['title'] = 'Anggota';

    if ($this->input->post('keyword') !== null)
{
    $this->session->set_userdata(
        'keyword_anggota',
        $this->input->post('keyword')
    );
}

$keyword = $this->session->userdata('keyword_anggota');
$data['keyword'] = $keyword;

    // ==========================
    // Pagination
    // ==========================

    $config['base_url']   = base_url('anggota/index');
    if ($keyword)
{
    $config['total_rows'] =
        $this->Anggota_model->countSearch($keyword);
}
else
{
    $config['total_rows'] =
        $this->Anggota_model->countAll();
}
    $config['per_page']   = 5;

    $this->pagination->initialize($config);

    $start = $this->uri->segment(3);

    if (!$start)
    {
        $start = 0;
    }

    $data['start'] = $start;

    // Ambil data sesuai halaman
    if ($keyword)
{
    $data['anggota'] =
        $this->Anggota_model->search(
            $keyword,
            $config['per_page'],
            $start
        );
}
else
{
    $data['anggota'] =
        $this->Anggota_model->getPagination(
            $config['per_page'],
            $start
        );
}

    // Link Pagination
    $data['pagination'] = $this->pagination->create_links();

    $this->load->view('templates/header', $data);
    $this->load->view('templates/sidebar');
    $this->load->view('templates/topbar');
    $this->load->view('anggota/index', $data);
    $this->load->view('templates/footer');
}

public function reset()
{
    $this->session->unset_userdata('keyword_anggota');
    redirect('anggota');
}
    /*
===================================
FORM TAMBAH ANGGOTA
===================================
*/

public function tambah()
{
    $data['title'] = 'Tambah Anggota';

   // Validasi
    $this->form_validation->set_rules('nama_anggota','Nama Anggota','required',
        [
            'required' => 'Nama Anggota wajib diisi.'
        ]
    );
    $this->form_validation->set_rules('alamat','Alamat Anggota','required',
        [
            'required' => 'Alamat Anggota wajib diisi.'
        ]
    );
    $this->form_validation->set_rules('telepon','No Telp Anggota','required',
        [
            'required' => 'No Telp Anggota wajib diisi.'
        ]
    );
    $this->form_validation->set_rules('email','Email Anggota','required',
        [
            'required' => 'Email Anggota wajib diisi.'
        ]
    );

    if ($this->form_validation->run() == FALSE)
    {

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar');
        $this->load->view('templates/topbar');
        $this->load->view('anggota/tambah');
        $this->load->view('templates/footer');

    }
    else
{

    $data = [
    'nama_anggota' => $this->input->post('nama_anggota'),
    'alamat'=> $this->input->post('alamat'),
    'telepon'=> $this->input->post('telepon'),
    'email'=> $this->input->post('email'),
    'foto'=> $this->input->post('foto')
];

    $this->Anggota_model->insert($data);

    $this->session->set_flashdata(
                'message',

                '<div class="alert alert-success alert-dismissible fade show" role="alert">

                    Data Anggota berhasil ditambahkan.

                    <button type="button"
                            class="close"
                            data-dismiss="alert">

                        <span>&times;</span>

                    </button>

                </div>'
            );

    redirect('anggota');

}
}

/*
===================================
FORM EDIT ANGGOTA
===================================
*/

public function edit($id)
{
    $data['title'] = 'Edit Anggota';

    $data['anggota'] = $this->Anggota_model->getById($id);

    // Validasi
    $this->form_validation->set_rules('nama_anggota','Nama Anggota','required',
        [
            'required' => 'Nama Anggota wajib diisi.'
        ]
    );
    $this->form_validation->set_rules('alamat','Alamat Anggota','required',
        [
            'required' => 'Alamat Anggota wajib diisi.'
        ]
    );
    $this->form_validation->set_rules('telepon','No Telp Anggota','required',
        [
            'required' => 'No Telp Anggota wajib diisi.'
        ]
    );
    $this->form_validation->set_rules('email','Email Anggota','required',
        [
            'required' => 'Email Anggota wajib diisi.'
        ]
    );

    if ($this->form_validation->run() == FALSE)
    {

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar');
        $this->load->view('templates/topbar');
        $this->load->view('anggota/edit', $data);
        $this->load->view('templates/footer');

    }
    else
{

    $data = [
    'nama_anggota' => $this->input->post('nama_anggota'),
    'alamat'=> $this->input->post('alamat'),
    'telepon'=> $this->input->post('telepon'),
    'email'=> $this->input->post('email'),
    'foto'=> $this->input->post('foto')
];

    $this->Anggota_model->update($id, $data);

    $this->session->set_flashdata(
                'message',
                '<div class="alert alert-success">
                    Data Anggota berhasil diubah!
                </div>'
            );

    redirect('anggota');

}

}

/*
===================================
HAPUS DATA ANGGOTA
===================================
*/

public function hapus($id)
{

    $this->Anggota_model->delete($id);

    $this->session->set_flashdata(
            'message',
            '<div class="alert alert-success">
                Data Anggota berhasil dihapus!
            </div>'
        );

    redirect('anggota');

}



}