<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();

        // Load Model (akan dipakai pada Stage 5B)
        $this->load->model('User_model');

        // Load Form Validation
        $this->load->library('form_validation');
    }

    /*
    ===================================
    HALAMAN LOGIN
    ===================================
    */

    public function index()
    {
        $this->load->view('auth/login');
    }

    /*
    ===================================
    PROSES LOGIN
    ===================================
    */

    public function login()
    {

        $username = $this->input->post('username');

        $password = $this->input->post('password');

        $user = $this->User_model->cekUsername($username);

        // Username tidak ditemukan
        if(!$user)
        {

            $this->session->set_flashdata(

                'message',

                '<div class="alert alert-danger">

                    Username tidak ditemukan.

                </div>'

            );

            redirect('login');

        }
        else
        {

            // Password salah
            if($password != $user->password)
            {

                $this->session->set_flashdata(

                    'message',

                    '<div class="alert alert-danger">

                        Password salah.

                    </div>'

                );

                redirect('login');

            }
            else
            {

                // Membuat Session Login
                $data = [

                    'id_user'   => $user->id_user,

                    'id_role'   => $user->id_role,

                    'nama'      => $user->nama,

                    'username'  => $user->username,

                    'login'     => TRUE

                ];

                $this->session->set_userdata($data);

                // Redirect ke Dashboard
                redirect('dashboard');

            }

        }

    }

    /*
    ===================================
    LOGOUT
    ===================================
    */

    public function logout()
    {
        // Menghapus seluruh session login
        $this->session->unset_userdata('id_user');
        $this->session->unset_userdata('nama');
        $this->session->unset_userdata('username');
        $this->session->unset_userdata('id_role');

        redirect('login');
    }

}