<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Buku extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        // Cek Login
        if (!$this->session->userdata('id_user'))
        {
            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-danger">
                    <strong>Perhatian!</strong><br>
                    Silakan login terlebih dahulu.
                </div>'
            );

            redirect('login');
        }

        // Hak Akses
        if (
            $this->session->userdata('id_role') != ROLE_ADMIN &&
            $this->session->userdata('id_role') != ROLE_PETUGAS
        )
        {
            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-danger">
                    <strong>Akses Ditolak!</strong><br>
                    Anda tidak memiliki hak akses ke halaman Buku.
                </div>'
            );

            redirect('dashboard');
        }

        $this->load->model('Buku_model');
        $this->load->library('pagination');
    }

    // FUNGSI INDEX

    public function index()
{
    $data['title'] = 'Buku';

    if ($this->input->post('keyword') !== null)
    {
        $this->session->set_userdata(
            'keyword_buku',
            $this->input->post('keyword')
        );
    }

    $keyword = $this->session->userdata('keyword_buku');
    $data['keyword'] = $keyword;

    $config['base_url'] = base_url('buku/index');

    if ($keyword)
    {
        $config['total_rows'] =
            $this->Buku_model->countSearch($keyword);
    }
    else
    {
        $config['total_rows'] =
            $this->Buku_model->countAll();
    }

    $config['per_page'] = 5;

    $this->pagination->initialize($config);

    $start = $this->uri->segment(3);
    if (!$start)
    {
        $start = 0;
    }

    $data['start'] = $start;

    if ($keyword)
    {
        $data['buku'] = $this->Buku_model->search(
            $keyword,
            $config['per_page'],
            $start
        );
    }
    else
    {
        $data['buku'] = $this->Buku_model->getPagination(
            $config['per_page'],
            $start
        );
    }

    $data['pagination'] = $this->pagination->create_links();

    $this->load->view('templates/header', $data);
    $this->load->view('templates/sidebar');
    $this->load->view('templates/topbar');
    $this->load->view('buku/index', $data);
    $this->load->view('templates/footer');
}

// $data['buku'] = $this->Buku_model->getAll();
        // sudah tidak diperlukan lagi jika memakai pagination, karena data buku sejkarang diamil melalui getPagination()

// RESET

    public function reset()
{
    $this->session->unset_userdata('keyword_buku');
    redirect('buku');
}

    // METHOD TAMBAH

    public function tambah()
{
    $data['title'] = 'Tambah Buku';

    // AMBIL DATA

    $data['kategori'] = $this->Buku_model->getKategori();
    $data['penulis']  = $this->Buku_model->getPenulis();
    $data['penerbit'] = $this->Buku_model->getPenerbit();
    $data['rak']      = $this->Buku_model->getRak();

    // VALIDASI

    $this->form_validation->set_rules(
        'isbn',
        'ISBN',
        'required',
        ['required' => 'ISBN wajib diisi.']
    );

    $this->form_validation->set_rules(
        'judul',
        'Judul Buku',
        'required',
        ['required' => 'Judul Buku wajib diisi.']
    );

    $this->form_validation->set_rules(
        'id_kategori',
        'Kategori',
        'required',
        ['required' => 'Kategori wajib dipilih.']
    );

    $this->form_validation->set_rules(
        'id_penulis',
        'Penulis',
        'required',
        ['required' => 'Penulis wajib dipilih.']
    );

    $this->form_validation->set_rules(
        'id_penerbit',
        'Penerbit',
        'required',
        ['required' => 'Penerbit wajib dipilih.']
    );

    $this->form_validation->set_rules(
        'id_rak',
        'Rak',
        'required',
        ['required' => 'Rak wajib dipilih.']
    );


    $this->form_validation->set_rules(
        'tahun_terbit',
        'Tahun Terbit',
        'required',
        ['required' => 'Tahun Terbit wajib diisi.']
    );

    $this->form_validation->set_rules(
        'stok',
        'Stok',
        'required|integer',
        [
            'required' => 'Stok wajib diisi.',
            'integer'  => 'Stok harus berupa angka.'
        ]
    );


    /*
    $this->form_validation->set_rules(
        'cover',
        'Cover',
        'required',
        ['required' => 'Cover wajib diisi.']
    );

    */

    $this->form_validation->set_rules(
        'deskripsi',
        'Deskripsi',
        'required',
        ['required' => 'Deskripsi wajib diisi.']
    );

    $this->form_validation->set_rules(
        'status',
        'Status',
        'required',
        ['required' => 'Status wajib pilih.']
    );

    if ($this->form_validation->run() == FALSE)
    {
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar');
        $this->load->view('templates/topbar');
        $this->load->view('buku/tambah', $data);
        $this->load->view('templates/footer');
    }
    else
    {
        // Proses simpan ke database

        $simpan = [
    'judul'  => $this->input->post('judul'),
    'id_kategori' => $this->input->post('id_kategori'),
    'id_penulis'  => $this->input->post('id_penulis'),
    'id_penerbit' => $this->input->post('id_penerbit'),
    'id_rak'      => $this->input->post('id_rak'),
    'isbn'        => $this->input->post('isbn'),
    'tahun_terbit'       => $this->input->post('tahun_terbit'),
    'stok'        => $this->input->post('stok'),
    'deskripsi'   => $this->input->post('deskripsi'),
    'status'      => $this->input->post('status'),
    'cover'       => ''
];

$this->Buku_model->insert($simpan);

$this->session->set_flashdata(
                'message',

                '<div class="alert alert-success alert-dismissible fade show" role="alert">

                    Data Buku berhasil ditambahkan.

                    <button type="button"
                            class="close"
                            data-dismiss="alert">

                        <span>&times;</span>

                    </button>

                </div>'
            );

redirect('buku');
    }


}

// Method edit

public function edit($id)
{
    $data['title'] = 'Edit Buku';

    $data['buku']      = $this->Buku_model->getById($id);
    $data['kategori']  = $this->Buku_model->getKategori();
    $data['penulis']   = $this->Buku_model->getPenulis();
    $data['penerbit']  = $this->Buku_model->getPenerbit();
    $data['rak']       = $this->Buku_model->getRak();

    // Validasi
    $this->form_validation->set_rules('isbn', 'ISBN', 'required');
    $this->form_validation->set_rules('judul', 'Judul Buku', 'required');
    $this->form_validation->set_rules('id_kategori', 'Kategori', 'required');
    $this->form_validation->set_rules('id_penulis', 'Penulis', 'required');
    $this->form_validation->set_rules('id_penerbit', 'Penerbit', 'required');
    $this->form_validation->set_rules('id_rak', 'Rak', 'required');
    $this->form_validation->set_rules('tahun_terbit', 'Tahun Terbit', 'required');
    $this->form_validation->set_rules('stok', 'Stok', 'required|integer');
    $this->form_validation->set_rules('status', 'Status', 'required');

    if ($this->form_validation->run() == FALSE)
    {
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar');
        $this->load->view('templates/topbar');
        $this->load->view('buku/edit', $data);
        $this->load->view('templates/footer');
    }
    else
    {
        // Proses update database 

        $dataUpdate = [
    'isbn'         => $this->input->post('isbn'),
    'judul'        => $this->input->post('judul'),
    'id_kategori'  => $this->input->post('id_kategori'),
    'id_penulis'   => $this->input->post('id_penulis'),
    'id_penerbit'  => $this->input->post('id_penerbit'),
    'id_rak'       => $this->input->post('id_rak'),
    'tahun_terbit' => $this->input->post('tahun_terbit'),
    'stok'         => $this->input->post('stok'),
    'deskripsi'    => $this->input->post('deskripsi'),
    'status'       => $this->input->post('status')
];

$this->Buku_model->update($id, $dataUpdate);

    $this->session->set_flashdata(
                'message',
                '<div class="alert alert-success">
                    Data Buku berhasil diubah!
                </div>'
            );

redirect('buku');

    }

}

// METHOD HAPUS

public function hapus($id)
{
    $this->Buku_model->delete($id);

    $this->session->set_flashdata(
        'message',
        '<div class="alert alert-success">
            Data Buku berhasil dihapus!
        </div>'
    );

    redirect('buku');
}



}