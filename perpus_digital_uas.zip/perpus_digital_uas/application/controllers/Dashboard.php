<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

    public function __construct()
    {
        parent::__construct();

        if(!$this->session->userdata('id_user'))
{
    $this->session->set_flashdata(

        'message',

        '<div class="alert alert-warning alert-dismissible fade show" role="alert">

            <strong>Perhatian!</strong>

            Silakan login terlebih dahulu.

            

        </div>'

    );

    redirect('login');
}

$this->load->model('Dashboard_model');

    }

   public function index()
{

    $data['total_buku'] = $this->Dashboard_model->getTotalBuku();

    $data['total_ebook'] = $this->Dashboard_model->getTotalEbook();

    $data['total_anggota'] = $this->Dashboard_model->getTotalAnggota();

    $data['total_peminjaman_aktif'] =
        $this->Dashboard_model->getTotalPeminjamanAktif();

    $data['statistik_peminjaman'] =
        $this->Dashboard_model->getStatistikPeminjaman();

    $chart = array_fill(1, 12, 0);

    foreach ($data['statistik_peminjaman'] as $row)
    {
        $chart[(int)$row->bulan] = (int)$row->total;
    }

    $data['chart_peminjaman'] = array_values($chart);

    $data['status_buku'] =
        $this->Dashboard_model->getStatusBuku();

    $this->load->view('templates/header');
    $this->load->view('templates/sidebar');
    $this->load->view('templates/topbar');
    $this->load->view('dashboard/index', $data);
    $this->load->view('templates/footer');
    $this->load->view('templates/script', $data);

}



}