<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ebook extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        if (!$this->session->userdata('id_user'))
        {
            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-danger">
                    <strong>Perhatian!</strong><br>
                    Silakan login terlebih dahulu.
                </div>'
            );

            redirect('login');
        }

        $this->load->model('Ebook_model');
    }

    public function index()
{
    $data['title'] = 'E-Book';

    if ($this->input->post('keyword')) {
        $this->session->set_userdata(
            'keyword_ebook',
            $this->input->post('keyword', true)
        );
    }

    if ($this->input->post('reset')) {
        $this->session->unset_userdata('keyword_ebook');
        redirect('ebook');
    }

    $keyword = $this->session->userdata('keyword_ebook');

    if ($keyword) {
        $config['total_rows'] = $this->Ebook_model->countSearch($keyword);
    } else {
        $config['total_rows'] = $this->Ebook_model->countAll();
    }

    $config['base_url'] = base_url('ebook/index');
    $config['per_page'] = 5;

    $this->pagination->initialize($config);

    $start = $this->uri->segment(3) ?: 0;

    $data['start'] = $start;
    $data['keyword'] = $keyword;

    if ($keyword) {
        $data['ebook'] = $this->Ebook_model->search(
            $keyword,
            $config['per_page'],
            $start
        );
    } else {
        $data['ebook'] = $this->Ebook_model->getPagination(
            $config['per_page'],
            $start
        );
    }

    $data['pagination'] = $this->pagination->create_links();

    $this->load->view('templates/header', $data);
    $this->load->view('templates/sidebar');
    $this->load->view('templates/topbar');
    $this->load->view('ebook/index', $data);
    $this->load->view('templates/footer');
} // penutup method index


// RESET

    public function reset()
{
    $this->session->unset_userdata('keyword_ebook');
    redirect('ebook');
}

    public function tambah()
{

    if (!in_array($this->session->userdata('nama'),
              ['Administrator', 'Petugas Perpus'])) {
    $this->session->set_flashdata(
        'message',
        '<div class="alert alert-danger">
            Anda tidak memiliki hak akses.
        </div>'
    );
    redirect('ebook');
}


    $data['title'] = 'Tambah E-Book';
    $data['buku'] = $this->Ebook_model->getBuku();

    $this->form_validation->set_rules(
        'id_buku',
        'Buku',
        'required',
        ['required' => 'Buku wajib dipilih.']
    );

    $this->form_validation->set_rules(
        'file_pdf',
        'File PDF',
        'required',
        ['required' => 'File PDF wajib diisi.']
    );

    if ($this->form_validation->run() == FALSE)
    {
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar');
        $this->load->view('templates/topbar');
        $this->load->view('ebook/tambah', $data);
        $this->load->view('templates/footer');
    }
    else
    {
        // Proses simpan ke Database

        $data_insert = [
            'id_buku'  => $this->input->post('id_buku', true),
            'file_pdf' => $this->input->post('file_pdf', true)
          ];

         $this->Ebook_model->insert($data_insert);
         $this->session->set_flashdata(
                'message',

                '<div class="alert alert-success alert-dismissible fade show" role="alert">

                    Data Buku berhasil ditambahkan.

                    <button type="button"
                            class="close"
                            data-dismiss="alert">

                        <span>&times;</span>

                    </button>

                </div>'
            );

         redirect('ebook');
    }
} // penutup method tambah

public function edit($id)
{

    if (!in_array($this->session->userdata('nama'),
              ['Administrator', 'Petugas Perpus'])) {
    $this->session->set_flashdata(
        'message',
        '<div class="alert alert-danger">
            Anda tidak memiliki hak akses.
        </div>'
    );
    redirect('ebook');
}


    $data['title'] = 'Edit E-Book';
    $data['ebook'] = $this->Ebook_model->getById($id);
    $data['buku']  = $this->Ebook_model->getBuku();

    // VALIDASI
    $this->form_validation->set_rules('id_buku','Buku','required',['required' => 'Buku wajib dipilih.']);
    $this->form_validation->set_rules('file_pdf','File / Link E-Book','required',['required' => 'File / Link E-Book wajib diisi.']);

if ($this->form_validation->run() == FALSE)
    {
    $this->load->view('templates/header', $data);
    $this->load->view('templates/sidebar');
    $this->load->view('templates/topbar');
    $this->load->view('ebook/edit', $data);
    $this->load->view('templates/footer');
}
else
{
    // PROSES UPDATE DATA

    $data_update = [
    'id_buku'  => $this->input->post('id_buku', true),
    'file_pdf' => $this->input->post('file_pdf', true)
];

$this->Ebook_model->update($id, $data_update);
$this->session->set_flashdata(
                'message',
                '<div class="alert alert-success">
                    Data E-Book berhasil diubah!
                </div>'
            );

redirect('ebook');
}

} // penutup method edit

// METHOD HAPUS

public function hapus($id)
{

    if (!in_array($this->session->userdata('nama'),
              ['Administrator', 'Petugas Perpus'])) {
    $this->session->set_flashdata(
        'message',
        '<div class="alert alert-danger">
            Anda tidak memiliki hak akses.
        </div>'
    );
    redirect('ebook');
}

    $this->Ebook_model->delete($id);

    $this->session->set_flashdata(
        'message',
        '<div class="alert alert-success">
            Data E-Book berhasil dihapus!
        </div>'
    );

    redirect('ebook');
}


} // penutup