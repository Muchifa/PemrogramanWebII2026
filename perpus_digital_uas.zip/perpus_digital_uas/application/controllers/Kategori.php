<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kategori extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();

        // Cek Login
        if (!$this->session->userdata('id_user'))
        {
            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-danger">
                    <strong>Perhatian!</strong><br>
                    Silakan login terlebih dahulu.
                </div>'
            );

            redirect('login');
        }

        // Hak Akses
        if (
            $this->session->userdata('id_role') != ROLE_ADMIN &&
            $this->session->userdata('id_role') != ROLE_PETUGAS
        )
        {
            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-danger">
                    <strong>Akses Ditolak!</strong><br>
                    Anda tidak memiliki hak akses ke halaman Kategori.
                </div>'
            );

            redirect('dashboard');
        }

        $this->load->model('Kategori_model');
        $this->load->library('pagination');
    }

   public function index()
{
    $data['title'] = 'Kategori';

    // ==========================
    // SEARCH
    // ==========================

    if ($this->input->post('keyword'))
    {
        $this->session->set_userdata(
            'keyword_kategori',
            $this->input->post('keyword')
        );
    }

    $keyword = $this->session->userdata('keyword_kategori');

    // ==========================
    // PAGINATION
    // ==========================

    $config['base_url'] = base_url('kategori/index');

    if ($keyword)
    {
        $config['total_rows'] = $this->Kategori_model->countSearch($keyword);
    }
    else
    {
        $config['total_rows'] = $this->Kategori_model->countAll();
    }

    $config['per_page'] = 5;

    $this->pagination->initialize($config);

    $start = $this->uri->segment(3);

    if (!$start)
    {
        $start = 0;
    }

    $data['start'] = $start;

    // ==========================
    // AMBIL DATA
    // ==========================

    if ($keyword)
    {
        $data['kategori'] = $this->Kategori_model->search(
            $keyword,
            $config['per_page'],
            $start
        );
    }
    else
    {
        $data['kategori'] = $this->Kategori_model->getPagination(
            $config['per_page'],
            $start
        );
    }

    $data['pagination'] = $this->pagination->create_links();

    $data['keyword'] = $keyword;

    $this->load->view('templates/header', $data);
    $this->load->view('templates/sidebar');
    $this->load->view('templates/topbar');
    $this->load->view('kategori/index', $data);
    $this->load->view('templates/footer');
}

/*
===================================
RESET SEARCH
===================================
*/

public function reset()
{
    $this->session->unset_userdata('keyword_kategori');

    redirect('kategori');
}

   /*
===================================
FORM TAMBAH KATEGORI
===================================
*/

public function tambah()
{
    $data['title'] = 'Tambah Kategori';

    // Validasi
    $this->form_validation->set_rules(
        'nama_kategori',
        'Nama Kategori',
        'required',
        [
            'required' => 'Nama Kategori wajib diisi.'
        ]
    );

    if ($this->form_validation->run() == FALSE)
    {

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar');
        $this->load->view('templates/topbar');
        $this->load->view('kategori/tambah');
        $this->load->view('templates/footer');

    }
    else
{

    $data = [

        'nama_kategori' => $this->input->post('nama_kategori')

    ];

    $this->Kategori_model->insert($data);

    $this->session->set_flashdata(
                'message',

                '<div class="alert alert-success alert-dismissible fade show" role="alert">

                    Data Kategori berhasil ditambahkan.

                    <button type="button"
                            class="close"
                            data-dismiss="alert">

                        <span>&times;</span>

                    </button>

                </div>'
            );

    redirect('kategori');

}

}

/*
===================================
FORM EDIT KATEGORI
===================================
*/

public function edit($id)
{
    $data['title'] = 'Edit Kategori';

    $data['kategori'] = $this->Kategori_model->getById($id);

    // Validasi
    $this->form_validation->set_rules(
        'nama_kategori',
        'Nama Kategori',
        'required',
        [
            'required' => 'Nama Kategori wajib diisi.'
        ]
    );

    if ($this->form_validation->run() == FALSE)
    {

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar');
        $this->load->view('templates/topbar');
        $this->load->view('kategori/edit', $data);
        $this->load->view('templates/footer');

    }
    else
{

    $data = [

        'nama_kategori' => $this->input->post('nama_kategori')

    ];

    $this->Kategori_model->update($id, $data);

    $this->session->set_flashdata(
                'message',
                '<div class="alert alert-success">
                    Data Kategori berhasil diubah!
                </div>'
            );

    redirect('kategori');

}

}

/*
===================================
HAPUS DATA KATEGORI
===================================
*/

public function hapus($id)
{

    $this->Kategori_model->delete($id);

    $this->session->set_flashdata(
            'message',
            '<div class="alert alert-success">
                Data Kategori berhasil dihapus!
            </div>'
        );

    redirect('kategori');

}

}