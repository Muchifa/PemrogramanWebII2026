<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . '../vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class Laporan extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();

        if (!in_array(
        $this->session->userdata('nama'),
        ['Administrator', 'Petugas Perpus']
    )) {
        $this->session->set_flashdata(
            'message',
            '<div class="alert alert-danger">
                Anda tidak memiliki hak akses.
            </div>'
        );
        redirect('dashboard');
    }

        if (!$this->session->userdata('id_user')) {
            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-danger">
                <strong>Perhatian!</strong><br>
                    Silakan login terlebih dahulu.
                </div>'
            );
            redirect('login');
        }

        $this->load->model('Laporan_model');
        $this->load->library('pdf');
    }

    public function index()
{

    $data['judul'] = 'Laporan Peminjaman';

    $tanggal_awal = $this->input->post('tanggal_awal', true);
    $tanggal_akhir = $this->input->post('tanggal_akhir', true);

    $data['tanggal_awal'] = $tanggal_awal;
    $data['tanggal_akhir'] = $tanggal_akhir;

    $data['laporan'] = $this->Laporan_model->getLaporanPeminjaman(
        $tanggal_awal,
        $tanggal_akhir
    );

    $this->load->view('templates/header', $data);
    $this->load->view('templates/sidebar');
    $this->load->view('templates/topbar');
    $this->load->view('laporan/index', $data);
    $this->load->view('templates/footer');
    $this->load->view('templates/script');

}


public function exportPdf()
{

    $tanggal_awal  = $this->input->get('tanggal_awal', true);
    $tanggal_akhir = $this->input->get('tanggal_akhir', true);

    $data['laporan'] = $this->Laporan_model->getLaporanPeminjaman(
        $tanggal_awal,
        $tanggal_akhir
    );

    $html = $this->load->view(
        'laporan/pdf',
        $data,
        true
    );

    $this->pdf->dompdf->loadHtml($html);

    $this->pdf->dompdf->setPaper(
        'A4',
        'landscape'
    );

    $this->pdf->dompdf->render();

    $this->pdf->dompdf->stream(
        'laporan_peminjaman.pdf',
        array(
            'Attachment' => false
        )
    );

}

public function exportExcel()
{

    $tanggal_awal = $this->input->get('tanggal_awal', true);

    $tanggal_akhir = $this->input->get('tanggal_akhir', true);

    $laporan = $this->Laporan_model->getLaporanPeminjaman(
        $tanggal_awal,
        $tanggal_akhir
    );

    $spreadsheet = new Spreadsheet();

    $sheet = $spreadsheet->getActiveSheet();

    $sheet->setTitle('Laporan Peminjaman');

    $sheet->setCellValue('A1', 'LAPORAN PEMINJAMAN');
    $sheet->mergeCells('A1:G1');

    $sheet->getStyle('A1')->getFont()->setBold(true);
    $sheet->getStyle('A1')->getFont()->setSize(16);

    $sheet->getStyle('A1')->getAlignment()->setHorizontal(
        \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER
    );

    $sheet->setCellValue('A3', 'No');
    $sheet->setCellValue('B3', 'Tanggal Pinjam');
    $sheet->setCellValue('C3', 'Nama Anggota');
    $sheet->setCellValue('D3', 'Judul Buku');
    $sheet->setCellValue('E3', 'Jumlah');
    $sheet->setCellValue('F3', 'Status');
    $sheet->setCellValue('G3', 'Denda');

    $sheet->getStyle('A3:G3')->getFont()->setBold(true);

    $sheet->getStyle('A3:G3')->getAlignment()->setHorizontal(
        \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER
    );

    $baris = 4;

    $no = 1;

    foreach ($laporan as $lp)
    {

        $sheet->setCellValue('A' . $baris, $no++);

        $sheet->setCellValue(
            'B' . $baris,
            date('d-m-Y', strtotime($lp->tanggal_pinjam))
        );

        $sheet->setCellValue(
            'C' . $baris,
            $lp->nama_anggota
        );

        $sheet->setCellValue(
            'D' . $baris,
            $lp->judul
        );

        $sheet->setCellValue(
            'E' . $baris,
            $lp->jumlah
        );

        $sheet->setCellValue(
            'F' . $baris,
            $lp->status
        );

        $sheet->setCellValue(
            'G' . $baris,
            $lp->denda
        );

        $baris++;

    }

    foreach (range('A', 'G') as $kolom)
    {

        $sheet->getColumnDimension($kolom)
              ->setAutoSize(true);

    }

    $writer = new Xlsx($spreadsheet);

    $namaFile = 'Laporan_Peminjaman_' . date('Ymd_His') . '.xlsx';

    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');

    header('Content-Disposition: attachment; filename="' . $namaFile . '"');

    header('Cache-Control: max-age=0');

    $writer->save('php://output');

    exit;

}

public function printLaporan()
{

    $tanggal_awal = $this->input->get('tanggal_awal', true);

    $tanggal_akhir = $this->input->get('tanggal_akhir', true);

    $data['tanggal_awal'] = $tanggal_awal;

    $data['tanggal_akhir'] = $tanggal_akhir;

    $data['laporan'] = $this->Laporan_model->getLaporanPeminjaman(
        $tanggal_awal,
        $tanggal_akhir
    );

    $this->load->view(
        'laporan/print',
        $data
    );

}


}