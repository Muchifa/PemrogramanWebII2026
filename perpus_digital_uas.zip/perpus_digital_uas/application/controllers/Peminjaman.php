<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Peminjaman extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        if (!in_array(
        $this->session->userdata('nama'),
        ['Administrator', 'Petugas Perpus']
    )) {
        $this->session->set_flashdata(
            'message',
            '<div class="alert alert-danger">
                Anda tidak memiliki hak akses.
            </div>'
        );
        redirect('dashboard');
    }

        if (!$this->session->userdata('id_user')) {
            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-danger">
                <strong>Perhatian!</strong><br>
                    Silakan login terlebih dahulu.
                </div>'
            );
            redirect('login');
        }

        $this->load->model('Peminjaman_model');
    }

    // METHOD INDEX

    public function index()
{
    if (!in_array(
        $this->session->userdata('nama'),
        ['Administrator', 'Petugas Perpus']
    )) {
        $this->session->set_flashdata(
            'message',
            '<div class="alert alert-danger">
                Anda tidak memiliki hak akses.
            </div>'
        );
        redirect('dashboard');
    }

    $data['title'] = 'Peminjaman';

    if ($this->input->post('keyword')) {
        $this->session->set_userdata(
            'keyword_peminjaman',
            $this->input->post('keyword', true)
        );
    }

    if ($this->input->post('reset')) {
        $this->session->unset_userdata('keyword_peminjaman');
        redirect('peminjaman');
    }

    $keyword = $this->session->userdata('keyword_peminjaman');

    $config['base_url'] = base_url('peminjaman/index');
    $config['per_page'] = 5;

    $config['total_rows'] = $this->Peminjaman_model
        ->countAll($keyword);

    $this->pagination->initialize($config);

    $start = $this->uri->segment(3) ?: 0;

    $data['start'] = $start;
    $data['keyword'] = $keyword;

    $data['peminjaman'] = $this->Peminjaman_model
        ->getPagination(
            $config['per_page'],
            $start,
            $keyword
        );

    $data['pagination'] = $this->pagination->create_links();

    $this->load->view('templates/header', $data);
    $this->load->view('templates/sidebar');
    $this->load->view('templates/topbar');
    $this->load->view('peminjaman/index', $data);
    $this->load->view('templates/footer');
} // PENUTUP INDEX

// RESET

    public function reset()
{
    $this->session->unset_userdata('keyword_peminjaman');
    redirect('peminjaman');
}

    // METHOD TAMBAH

    public function tambah()
{

    if (!in_array($this->session->userdata('nama'),
              ['Administrator', 'Petugas Perpus'])) {
    $this->session->set_flashdata(
        'message',
        '<div class="alert alert-danger">
            Anda tidak memiliki hak akses.
        </div>'
    );
    redirect('dashboard');
}


    $data['title'] = 'Tambah Peminjaman';
    $data['anggota'] = $this->Peminjaman_model->getAnggota();

    $this->form_validation->set_rules(
    'id_anggota',
    'Anggota',
    'required',
    ['required' => 'Anggota wajib dipilih.']
);

$this->form_validation->set_rules(
    'tanggal_pinjam',
    'Tanggal Pinjam',
    'required',
    ['required' => 'Tanggal pinjam wajib diisi.']
);

$this->form_validation->set_rules(
    'tanggal_jatuh_tempo',
    'Tanggal Jatuh Tempo',
    'required',
    ['required' => 'Tanggal jatuh tempo wajib diisi.']
);

if ($this->form_validation->run() == FALSE)
    {
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar');
        $this->load->view('templates/topbar');
        $this->load->view('peminjaman/tambah', $data);
        $this->load->view('templates/footer');
    }
    else
    {
        // PROSES SIMPAN DATA
        $dataSimpan = [
    'id_anggota'            => $this->input->post('id_anggota', true),
    'id_user'               => $this->session->userdata('id_user'),
    'tanggal_pinjam'        => $this->input->post('tanggal_pinjam', true),
    'tanggal_jatuh_tempo'   => $this->input->post('tanggal_jatuh_tempo', true),
    'status'                => 'Dipinjam'
];

$this->Peminjaman_model->insert($dataSimpan);

// Flash message 
$this->session->set_flashdata(
                'message',

                '<div class="alert alert-success alert-dismissible fade show" role="alert">

                    Data Peminjaman berhasil ditambahkan.

                    <button type="button"
                            class="close"
                            data-dismiss="alert">

                        <span>&times;</span>

                    </button>

                </div>'
            );

redirect('peminjaman');
    }


} // PENUTUP TAMBAH

// METHOD HAPUS

public function hapus($id)
{
    if (!in_array(
        $this->session->userdata('nama'),
        ['Administrator', 'Petugas Perpus']
    )) {
        $this->session->set_flashdata(
            'message',
            '<div class="alert alert-danger">
                Anda tidak memiliki hak akses.
            </div>'
        );
        redirect('peminjaman');
    }

    if ($this->Peminjaman_model->countDetail($id) > 0) {
        $this->session->set_flashdata(
            'message',
            '<div class="alert alert-danger">
                Hapus dahulu semua detail buku pada transaksi ini.
            </div>'
        );
        redirect('peminjaman');
    }

    $this->Peminjaman_model->delete($id);

    $this->session->set_flashdata(
        'message',
        '<div class="alert alert-success">
            Data Peminjaman berhasil dihapus!
        </div>'
    );

    redirect('peminjaman');
} // PENUTUP DELETE

// METHOD DETAIL
public function detail($id)
{

    if (!in_array($this->session->userdata('nama'),
              ['Administrator', 'Petugas Perpus'])) {
    $this->session->set_flashdata(
        'message',
        '<div class="alert alert-danger">
            Anda tidak memiliki hak akses.
        </div>'
    );
    redirect('peminjaman');
}

    $data['title'] = 'Detail Peminjaman';
    $data['pinjam'] = $this->Peminjaman_model->getById($id);
    // $data['anggota'] = $this->Peminjaman_model->getByNamaAnggota($nama_anggota);
    $data['detail'] = $this->Peminjaman_model->getDetailPinjam($id);
    $data['buku'] = $this->Peminjaman_model->getBuku();

    // VALIDASI
    $this->form_validation->set_rules('id_buku','Buku','required',['required' => 'Buku wajib dipilih.']
);

    $this->form_validation->set_rules('jumlah','Jumlah','required|integer|greater_than[0]',
    [
        'required'     => 'Jumlah wajib diisi.',
        'integer'      => 'Jumlah harus berupa angka.',
        'greater_than' => 'Jumlah minimal 1.'
    ]
);

    if ($this->form_validation->run() == FALSE)
    {
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar');
        $this->load->view('templates/topbar');
        $this->load->view('peminjaman/detail', $data);
        $this->load->view('templates/footer');
    }
    else
    {

        // CEK STOK

        $buku = $this->Peminjaman_model->getBukuById(
    $this->input->post('id_buku')
);

if ($this->input->post('jumlah') > $buku->stok) {
    $this->session->set_flashdata(
        'message',
        '<div class="alert alert-danger">
            Jumlah pinjam melebihi stok yang tersedia.
        </div>'
    );

    redirect('peminjaman/detail/'.$id);
}

// INPUT DATA PINJAM DAN KURANGI STOK

$detail = [
    'id_pinjam' => $id,
    'id_buku'   => $this->input->post('id_buku', true),
    'jumlah'    => $this->input->post('jumlah', true)
];

$this->Peminjaman_model->insertDetail($detail);

$this->Peminjaman_model->updateStok(
    $detail['id_buku'],
    $detail['jumlah']
);

$this->session->set_flashdata(
    'message',
    '<div class="alert alert-success">
        Buku berhasil ditambahkan ke peminjaman.
    </div>'
);

redirect('peminjaman/detail/'.$id);

    }



} // penutup detail

// METHOD HAPUS DETAIL

public function hapusDetail($id_detail)
{

    if (!in_array(
        $this->session->userdata('nama'),
        ['Administrator', 'Petugas Perpus']
    )) {
        $this->session->set_flashdata(
            'message',
            '<div class="alert alert-danger">
                Anda tidak memiliki hak akses.
            </div>'
        );
        redirect('peminjaman');
    }

    $detail = $this->Peminjaman_model->getDetailById($id_detail);

    if (!$detail) {
        show_404();
    }

    $id_pinjam = $detail->id_pinjam;

    $this->Peminjaman_model->tambahStok(
        $detail->id_buku,
        $detail->jumlah
    );

    $this->Peminjaman_model->hapusDetail($id_detail);

    $this->session->set_flashdata(
        'message',
        '<div class="alert alert-success">
            Buku berhasil dihapus dari peminjaman.
        </div>'
    );

    redirect('peminjaman/detail/' . $id_pinjam);
} // penutup hapus detail


}// PENUTUP CONTROLLER