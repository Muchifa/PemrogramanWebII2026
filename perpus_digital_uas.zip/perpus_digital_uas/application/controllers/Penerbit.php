<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Penerbit extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();

        // Cek Login
        if (!$this->session->userdata('id_user'))
        {
            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-danger">
                    <strong>Perhatian!</strong><br>
                    Silakan login terlebih dahulu.
                </div>'
            );

            redirect('login');
        }

        // Hak Akses
        if (
            $this->session->userdata('id_role') != ROLE_ADMIN &&
            $this->session->userdata('id_role') != ROLE_PETUGAS
        )
        {
            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-danger">
                    <strong>Akses Ditolak!</strong><br>
                    Anda tidak memiliki hak akses ke halaman Penerbit.
                </div>'
            );

            redirect('dashboard');
        }

        $this->load->model('Penerbit_model');
        $this->load->library('pagination');
    }

    public function index()
{
    $data['title'] = 'Penerbit';

    if ($this->input->post('keyword') !== null)
{
    $this->session->set_userdata(
        'keyword_penerbit',
        $this->input->post('keyword')
    );
}

$keyword = $this->session->userdata('keyword_penerbit');
$data['keyword'] = $keyword;

    // ==========================
    // Pagination
    // ==========================

    $config['base_url']   = base_url('penerbit/index');
    if ($keyword)
{
    $config['total_rows'] =
        $this->Penerbit_model->countSearch($keyword);
}
else
{
    $config['total_rows'] =
        $this->Penerbit_model->countAll();
}
    $config['per_page']   = 5;

    $this->pagination->initialize($config);

    $start = $this->uri->segment(3);

    if (!$start)
    {
        $start = 0;
    }

    $data['start'] = $start;

    // Ambil data sesuai halaman
    if ($keyword)
{
    $data['penerbit'] =
        $this->Penerbit_model->search(
            $keyword,
            $config['per_page'],
            $start
        );
}
else
{
    $data['penerbit'] =
        $this->Penerbit_model->getPagination(
            $config['per_page'],
            $start
        );
}

    // Link Pagination
    $data['pagination'] = $this->pagination->create_links();

    $this->load->view('templates/header', $data);
    $this->load->view('templates/sidebar');
    $this->load->view('templates/topbar');
    $this->load->view('penerbit/index', $data);
    $this->load->view('templates/footer');
}

public function reset()
{
    $this->session->unset_userdata('keyword_penerbit');
    redirect('penerbit');
}
    /*
===================================
FORM TAMBAH PENERBIT
===================================
*/

public function tambah()
{
    $data['title'] = 'Tambah Penerbit';

   // Validasi
    $this->form_validation->set_rules('nama_penerbit','Nama Penerbit','required',
        [
            'required' => 'Nama Penerbit wajib diisi.'
        ]
    );
    $this->form_validation->set_rules('alamat','Alamat Penerbit','required',
        [
            'required' => 'Alamat Penerbit wajib diisi.'
        ]
    );
    $this->form_validation->set_rules('telepon','No Telepon Penerbit','required',
        [
            'required' => 'No Telepon Penerbit wajib diisi.'
        ]
    );

    if ($this->form_validation->run() == FALSE)
    {

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar');
        $this->load->view('templates/topbar');
        $this->load->view('penerbit/tambah');
        $this->load->view('templates/footer');

    }
    else
{

    $data = [
    'nama_penerbit' => $this->input->post('nama_penerbit'),
    'alamat'        => $this->input->post('alamat'),
    'telepon'       => $this->input->post('telepon')
];

    $this->Penerbit_model->insert($data);

    $this->session->set_flashdata(
                'message',

                '<div class="alert alert-success alert-dismissible fade show" role="alert">

                    Data Penerbit berhasil ditambahkan.

                    <button type="button"
                            class="close"
                            data-dismiss="alert">

                        <span>&times;</span>

                    </button>

                </div>'
            );

    redirect('penerbit');

}
}

/*
===================================
FORM EDIT PENERBIT
===================================
*/

public function edit($id)
{
    $data['title'] = 'Edit Penerbit';

    $data['penerbit'] = $this->Penerbit_model->getById($id);

    // Validasi
    $this->form_validation->set_rules('nama_penerbit','Nama Penerbit','required',
        [
            'required' => 'Nama Penerbit wajib diisi.'
        ]
    );
    $this->form_validation->set_rules('alamat','Alamat Penerbit','required',
        [
            'required' => 'Alamat Penerbit wajib diisi.'
        ]
    );
    $this->form_validation->set_rules('telepon','No Telepon Penerbit','required',
        [
            'required' => 'No Telepon Penerbit wajib diisi.'
        ]
    );

    if ($this->form_validation->run() == FALSE)
    {

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar');
        $this->load->view('templates/topbar');
        $this->load->view('penerbit/edit', $data);
        $this->load->view('templates/footer');

    }
    else
{

    $data = [
    'nama_penerbit' => $this->input->post('nama_penerbit'),
    'alamat'        => $this->input->post('alamat'),
    'telepon'       => $this->input->post('telepon')
];

    $this->Penerbit_model->update($id, $data);

    $this->session->set_flashdata(
                'message',
                '<div class="alert alert-success">
                    Data Penerbit berhasil diubah!
                </div>'
            );

    redirect('penerbit');

}

}

/*
===================================
HAPUS DATA PENERBIT
===================================
*/

public function hapus($id)
{

    $this->Penerbit_model->delete($id);

    $this->session->set_flashdata(
            'message',
            '<div class="alert alert-success">
                Data Penerbit berhasil dihapus!
            </div>'
        );

    redirect('penerbit');

}



}