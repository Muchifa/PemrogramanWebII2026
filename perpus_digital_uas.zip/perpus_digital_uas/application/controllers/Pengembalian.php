<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pengembalian extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        if (!in_array(
        $this->session->userdata('nama'),
        ['Administrator', 'Petugas Perpus']
    )) {
        $this->session->set_flashdata(
            'message',
            '<div class="alert alert-danger">
                Anda tidak memiliki hak akses.
            </div>'
        );
        redirect('dashboard');
    }

        if (!$this->session->userdata('id_user')) {
            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-danger">
                <strong>Perhatian!</strong><br>
                    Silakan login terlebih dahulu.
                </div>'
            );
            redirect('login');
        }

        $this->load->model('Pengembalian_model');
    }

    public function index()
{
    if (!in_array(
        $this->session->userdata('nama'),
        ['Administrator', 'Petugas Perpus']
    )) {
        $this->session->set_flashdata(
            'message',
            '<div class="alert alert-danger">
                Anda tidak memiliki hak akses.
            </div>'
        );
        redirect('dashboard');
    }

    $data['title'] = 'Pengembalian';

    if ($this->input->post('keyword')) {
        $this->session->set_userdata(
            'keyword_pengembalian',
            $this->input->post('keyword', true)
        );
    }

    if ($this->input->post('reset')) {
        $this->session->unset_userdata('keyword_pengembalian');
        redirect('pengembalian');
    }

    $keyword = $this->session->userdata('keyword_pengembalian');

    $config['base_url'] = base_url('pengembalian/index');
    $config['per_page'] = 5;
    $config['total_rows'] =
        $this->Pengembalian_model->countAll($keyword);

    $this->pagination->initialize($config);

    $start = $this->uri->segment(3) ?: 0;

    $data['start'] = $start;
    $data['keyword'] = $keyword;

    $data['pengembalian'] =
        $this->Pengembalian_model->getPagination(
            $config['per_page'],
            $start,
            $keyword
        );

    $data['pagination'] = $this->pagination->create_links();

    $this->load->view('templates/header', $data);
    $this->load->view('templates/sidebar');
    $this->load->view('templates/topbar');
    $this->load->view('pengembalian/index', $data);
    $this->load->view('templates/footer');
} // penutup index

// METHOD RESET

    public function reset()
{

    if (!in_array(
        $this->session->userdata('nama'),
        ['Administrator', 'Petugas Perpus']
    )) {
        $this->session->set_flashdata(
            'message',
            '<div class="alert alert-danger">
                Anda tidak memiliki hak akses.
            </div>'
        );
        redirect('dashboard');
    }

    $this->session->unset_userdata('keyword_pengembalian');
    redirect('pengembalian');
}


// METHOD PROSES

public function proses($id_pinjam)
{

    if (!in_array(
        $this->session->userdata('nama'),
        ['Administrator', 'Petugas Perpus']
    )) {
        $this->session->set_flashdata(
            'message',
            '<div class="alert alert-danger">
                Anda tidak memiliki hak akses.
            </div>'
        );
        redirect('dashboard');
    }

    $data['title'] = 'Proses Pengembalian';
    $data['detail'] = $this->Pengembalian_model->getDetailBelumKembali($id_pinjam);

    $this->load->view('templates/header', $data);
    $this->load->view('templates/sidebar');
    $this->load->view('templates/topbar');
    $this->load->view('pengembalian/proses', $data);
    $this->load->view('templates/footer');
}

public function kembalikan($id_detail)
{

    if (!in_array(
        $this->session->userdata('nama'),
        ['Administrator', 'Petugas Perpus']
    )) {
        $this->session->set_flashdata(
            'message',
            '<div class="alert alert-danger">
                Anda tidak memiliki hak akses.
            </div>'
        );
        redirect('dashboard');
    }

    $detail = $this->db
        ->select('d.*, p.tanggal_jatuh_tempo')
        ->from('tbl_detail_pinjam d')
        ->join('tbl_peminjaman p', 'p.id_pinjam = d.id_pinjam')
        ->where('d.id_detail', $id_detail)
        ->get()
        ->row();

    if (!$detail) {
        show_404();
    }

    if ($detail->tanggal_kembali !== null) {
        $this->session->set_flashdata(
            'message',
            '<div class="alert alert-warning">
                Buku ini sudah dikembalikan sebelumnya.
            </div>'
        );
        redirect('pengembalian/proses/' . $detail->id_pinjam);
    }

    $tanggal_kembali = date('Y-m-d');

    $terlambat = max(
        0,
        (strtotime($tanggal_kembali) - strtotime($detail->tanggal_jatuh_tempo))
        / 86400
    );

    $denda = (int)$terlambat * 1000; // Rp1.000 per hari

    $this->Pengembalian_model->setPengembalian(
        $id_detail,
        $tanggal_kembali,
        $denda
    );

    if ($this->Pengembalian_model->countBelumKembali($detail->id_pinjam) == 0) {
        $this->Pengembalian_model->setSelesai($detail->id_pinjam);
    }

    $pesan = 'Buku berhasil dikembalikan.';
    if ($denda > 0) {
        $pesan .= ' Denda: Rp' . number_format($denda, 0, ',', '.');
    }

    $this->session->set_flashdata(
        'message',
        '<div class="alert alert-success">' . $pesan . '</div>'
    );

    redirect('pengembalian/proses/' . $detail->id_pinjam);
}

} // penutup controller