<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Penulis extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();

        // Cek Login
        if (!$this->session->userdata('id_user'))
        {
            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-danger">
                    <strong>Perhatian!</strong><br>
                    Silakan login terlebih dahulu.
                </div>'
            );

            redirect('login');
        }

        // Hak Akses
        if (
            $this->session->userdata('id_role') != ROLE_ADMIN &&
            $this->session->userdata('id_role') != ROLE_PETUGAS
        )
        {
            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-danger">
                    <strong>Akses Ditolak!</strong><br>
                    Anda tidak memiliki hak akses ke halaman Penulis.
                </div>'
            );

            redirect('dashboard');
        }

        $this->load->model('Penulis_model');
        $this->load->library('pagination');
    }

    public function index()
{
    $data['title'] = 'Penulis';

    if ($this->input->post('keyword') !== null)
{
    $this->session->set_userdata(
        'keyword_penulis',
        $this->input->post('keyword')
    );
}

$keyword = $this->session->userdata('keyword_penulis');
$data['keyword'] = $keyword;

    // ==========================
    // Pagination
    // ==========================

    $config['base_url']   = base_url('penulis/index');
    if ($keyword)
{
    $config['total_rows'] =
        $this->Penulis_model->countSearch($keyword);
}
else
{
    $config['total_rows'] =
        $this->Penulis_model->countAll();
}
    $config['per_page']   = 5;

    $this->pagination->initialize($config);

    $start = $this->uri->segment(3);

    if (!$start)
    {
        $start = 0;
    }

    $data['start'] = $start;

    // Ambil data sesuai halaman
    if ($keyword)
{
    $data['penulis'] =
        $this->Penulis_model->search(
            $keyword,
            $config['per_page'],
            $start
        );
}
else
{
    $data['penulis'] =
        $this->Penulis_model->getPagination(
            $config['per_page'],
            $start
        );
}

    // Link Pagination
    $data['pagination'] = $this->pagination->create_links();

    $this->load->view('templates/header', $data);
    $this->load->view('templates/sidebar');
    $this->load->view('templates/topbar');
    $this->load->view('penulis/index', $data);
    $this->load->view('templates/footer');
}

public function reset()
{
    $this->session->unset_userdata('keyword_penulis');
    redirect('penulis');
}
    /*
===================================
FORM TAMBAH PENULIS
===================================
*/

public function tambah()
{
    $data['title'] = 'Tambah Penulis';

   // Validasi
    $this->form_validation->set_rules(
        'nama_penulis',
        'Nama Penulis',
        'required',
        [
            'required' => 'Nama Penulis wajib diisi.'
        ]
    );

    if ($this->form_validation->run() == FALSE)
    {

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar');
        $this->load->view('templates/topbar');
        $this->load->view('penulis/tambah');
        $this->load->view('templates/footer');

    }
    else
{

    $data = [

        'nama_penulis' => $this->input->post('nama_penulis')

    ];

    $this->Penulis_model->insert($data);

    $this->session->set_flashdata(
                'message',

                '<div class="alert alert-success alert-dismissible fade show" role="alert">

                    Data Penulis berhasil ditambahkan.

                    <button type="button"
                            class="close"
                            data-dismiss="alert">

                        <span>&times;</span>

                    </button>

                </div>'
            );

    redirect('penulis');

}
}

/*
===================================
FORM EDIT PENULIS
===================================
*/

public function edit($id)
{
    $data['title'] = 'Edit Penulis';

    $data['penulis'] = $this->Penulis_model->getById($id);

    // Validasi
    $this->form_validation->set_rules(
        'nama_penulis',
        'Nama Penulis',
        'required',
        [
            'required' => 'Nama Penulis wajib diisi.'
        ]
    );

    if ($this->form_validation->run() == FALSE)
    {

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar');
        $this->load->view('templates/topbar');
        $this->load->view('penulis/edit', $data);
        $this->load->view('templates/footer');

    }
    else
{

    $data = [

        'nama_penulis' => $this->input->post('nama_penulis')

    ];

    $this->Penulis_model->update($id, $data);

    $this->session->set_flashdata(
                'message',
                '<div class="alert alert-success">
                    Data Penulis berhasil diubah!
                </div>'
            );

    redirect('penulis');

}

}

/*
===================================
HAPUS DATA PENULIS
===================================
*/

public function hapus($id)
{

    $this->Penulis_model->delete($id);

    $this->session->set_flashdata(
            'message',
            '<div class="alert alert-success">
                Data Penulis berhasil dihapus!
            </div>'
        );

    redirect('penulis');

}



}