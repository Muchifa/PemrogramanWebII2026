<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Rak extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();

        // Cek Login
        if (!$this->session->userdata('id_user'))
        {
            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-danger">
                    <strong>Perhatian!</strong><br>
                    Silakan login terlebih dahulu.
                </div>'
            );

            redirect('login');
        }

        // Hak Akses
        if (
            $this->session->userdata('id_role') != ROLE_ADMIN &&
            $this->session->userdata('id_role') != ROLE_PETUGAS
        )
        {
            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-danger">
                    <strong>Akses Ditolak!</strong><br>
                    Anda tidak memiliki hak akses ke halaman Rak.
                </div>'
            );

            redirect('dashboard');
        }

        $this->load->model('Rak_model');
        $this->load->library('pagination');
    }

    public function index()
{
    $data['title'] = 'Rak';

    if ($this->input->post('keyword') !== null)
{
    $this->session->set_userdata(
        'keyword_rak',
        $this->input->post('keyword')
    );
}

$keyword = $this->session->userdata('keyword_rak');
$data['keyword'] = $keyword;

    // ==========================
    // Pagination
    // ==========================

    $config['base_url']   = base_url('rak/index');
    if ($keyword)
{
    $config['total_rows'] =
        $this->Rak_model->countSearch($keyword);
}
else
{
    $config['total_rows'] =
        $this->Rak_model->countAll();
}
    $config['per_page']   = 5;

    $this->pagination->initialize($config);

    $start = $this->uri->segment(3);

    if (!$start)
    {
        $start = 0;
    }

    $data['start'] = $start;

    // Ambil data sesuai halaman
    if ($keyword)
{
    $data['rak'] =
        $this->Rak_model->search(
            $keyword,
            $config['per_page'],
            $start
        );
}
else
{
    $data['rak'] =
        $this->Rak_model->getPagination(
            $config['per_page'],
            $start
        );
}

    // Link Pagination
    $data['pagination'] = $this->pagination->create_links();

    $this->load->view('templates/header', $data);
    $this->load->view('templates/sidebar');
    $this->load->view('templates/topbar');
    $this->load->view('rak/index', $data);
    $this->load->view('templates/footer');
}

public function reset()
{
    $this->session->unset_userdata('keyword_rak');
    redirect('rak');
}
    /*
===================================
FORM TAMBAH RAK
===================================
*/

public function tambah()
{
    $data['title'] = 'Tambah Rak';

   // Validasi
    $this->form_validation->set_rules('nama_rak','Nama Rak','required',
        [
            'required' => 'Nama Rak wajib diisi.'
        ]
    );
    $this->form_validation->set_rules('lokasi','Lokasi Rak','required',
        [
            'required' => 'Lokasi Rak wajib diisi.'
        ]
    );

    if ($this->form_validation->run() == FALSE)
    {

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar');
        $this->load->view('templates/topbar');
        $this->load->view('rak/tambah');
        $this->load->view('templates/footer');

    }
    else
{

    $data = [
    'nama_rak' => $this->input->post('nama_rak'),
    'lokasi'        => $this->input->post('lokasi')
];

    $this->Rak_model->insert($data);

    $this->session->set_flashdata(
                'message',

                '<div class="alert alert-success alert-dismissible fade show" role="alert">

                    Data Rak berhasil ditambahkan.

                    <button type="button"
                            class="close"
                            data-dismiss="alert">

                        <span>&times;</span>

                    </button>

                </div>'
            );

    redirect('rak');

}
}

/*
===================================
FORM EDIT RAK
===================================
*/

public function edit($id)
{
    $data['title'] = 'Edit Rak';

    $data['rak'] = $this->Rak_model->getById($id);

    // Validasi
    $this->form_validation->set_rules('nama_rak','Nama Rak','required',
        [
            'required' => 'Nama Rak wajib diisi.'
        ]
    );
    $this->form_validation->set_rules('lokasi','Lokasi Rak','required',
        [
            'required' => 'Lokasi Rak wajib diisi.'
        ]
    );

    if ($this->form_validation->run() == FALSE)
    {

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar');
        $this->load->view('templates/topbar');
        $this->load->view('rak/edit', $data);
        $this->load->view('templates/footer');

    }
    else
{

    $data = [
    'nama_rak' => $this->input->post('nama_rak'),
    'lokasi'        => $this->input->post('lokasi')
];

    $this->Rak_model->update($id, $data);

    $this->session->set_flashdata(
                'message',
                '<div class="alert alert-success">
                    Data Rak berhasil diubah!
                </div>'
            );

    redirect('rak');

}

}

/*
===================================
HAPUS DATA RAK
===================================
*/

public function hapus($id)
{

    $this->Rak_model->delete($id);

    $this->session->set_flashdata(
            'message',
            '<div class="alert alert-success">
                Data Rak berhasil dihapus!
            </div>'
        );

    redirect('rak');

}



}