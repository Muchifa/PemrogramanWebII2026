<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Role extends CI_Controller {

    public function __construct()
    {
        parent::__construct();

        if(!$this->session->userdata('id_user'))
{
    $this->session->set_flashdata(

        'message',

        '<div class="alert alert-warning alert-dismissible fade show" role="alert">

            <strong>Perhatian!</strong>

            Silakan login terlebih dahulu.


        </div>'

    );

    redirect('login');
}

if($this->session->userdata('id_role') != ROLE_ADMIN)
{

    $this->session->set_flashdata(
        'message',
        '<div class="alert alert-danger">
            <strong>Akses Ditolak!</strong><br>
            Anda tidak memiliki hak akses ke halaman Role.
        </div>'
    );

    redirect('dashboard');

}

        $this->load->model('Role_model');
        $this->load->library('form_validation');
    }

    public function index()
{
    $data['title'] = 'Data Role';

    $data['total_role'] = $this->Role_model->jumlah();

    if($this->input->post('keyword'))
{
    $data['keyword'] =
        $this->input->post('keyword');

    $this->session->set_userdata(
        'keyword_role',
        $data['keyword']
    );
}
else
{
    $data['keyword'] =
        $this->session->userdata(
            'keyword_role'
        );
}

    // konfigurasi pagination
    $config['base_url'] = base_url('role/index');
    $config['total_rows']
    = $this->Role_model
           ->jumlahCari(
               $data['keyword']
           );
    $config['per_page'] = 4;
    $config['uri_segment'] = 3;
    $config['use_page_numbers'] = FALSE;

    $this->pagination->initialize($config);

    // menentukan halaman aktif
    $start = $this->uri->segment(3);

    if(!$start)
    {
        $start = 0;
    }

    // mengambil data sesuai limit pagination
    $data['role'] = $this->Role_model->getPagination(
        $config['per_page'],
        $start,
        $data['keyword']
    );

    // membuat link pagination
    $data['pagination'] = $this->pagination->create_links();

    // tes jika tbl role kosong
    // $data['total_role'] = 0;
    // $data['role'] = [];

    // load view
    $this->load->view('templates/header');
    $this->load->view('templates/sidebar');
    $this->load->view('templates/topbar');
    $this->load->view('role/index', $data);
    $this->load->view('templates/footer');
    $this->load->view('templates/script');
}

    public function tambah()
{
    $data['title'] = 'Tambah Role';

    $this->form_validation->set_rules(
        'nama_role',
        'Nama Role',
        'required',
        [
            'required' => 'Nama Role wajib diisi!'
        ]
    );

    if ($this->form_validation->run() == FALSE)
    {
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('templates/topbar');
        $this->load->view('role/tambah', $data);
        $this->load->view('templates/footer');
        $this->load->view('templates/script');
    }
    else
    {
        $this->Role_model->insert();

        $this->session->set_flashdata(
            'message',
            '<div class="alert alert-success">
                Data role berhasil ditambah!
             </div>'
        );

        redirect('role');
    }
}

public function edit($id)
{
    $data['title'] = 'Edit Role';
    $data['role'] = $this->Role_model->getById($id);

    $this->form_validation->set_rules(
        'nama_role',
        'Nama Role',
        'required',
        [
            'required' => 'Nama Role wajib diisi!'
        ]
    );

    if ($this->form_validation->run() == FALSE)
    {
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('templates/topbar');
        $this->load->view('role/edit', $data);
        $this->load->view('templates/footer');
        $this->load->view('templates/script');
    }
    else
{
    $this->Role_model->update();

    $this->session->set_flashdata(
        'message',
        '<div class="alert alert-success">
            Data role berhasil diubah!
        </div>'
    );

    redirect('role');
}

}

public function delete($id)
{

    $this->Role_model->delete($id);

    $this->session->set_flashdata(
        'message',
        '<div class="alert alert-success">
            Data role berhasil dihapus!
        </div>'
    );

    redirect('role');
}

public function update()
{
    $this->Role_model->update();

    redirect('role');
}

public function reset()
{
    $this->session->unset_userdata('keyword_role');

    redirect('role');
}

}