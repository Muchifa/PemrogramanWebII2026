<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

    public function __construct()
    {
        parent::__construct();

        if(!$this->session->userdata('id_user'))
{
    $this->session->set_flashdata(

        'message',

        '<div class="alert alert-warning alert-dismissible fade show" role="alert">

            <strong>Perhatian!</strong>

            Silakan login terlebih dahulu.


        </div>'

    );

    redirect('login');
}

if($this->session->userdata('id_role') != ROLE_ADMIN)
{

    $this->session->set_flashdata(
        'message',
        '<div class="alert alert-danger">
            <strong>Akses Ditolak!</strong><br>
            Anda tidak memiliki hak akses ke halaman User.
        </div>'
    );

    redirect('dashboard');

}

        $this->load->model('User_model');
    }

    public function index()
    {
        $data['title'] = 'Data User';

        // ===========================
        // SEARCH + SESSION
        // ===========================

        if($this->input->post('keyword'))
        {
            $this->session->set_userdata(
                'keyword_user',
                $this->input->post('keyword')
            );
        }

        $data['keyword'] = $this->session->userdata('keyword_user');

        // ===========================
        // PAGINATION
        // ===========================

        $config['base_url'] = base_url('user/index');
        $config['total_rows'] = $this->User_model->jumlah($data['keyword']);
        $config['per_page'] = 2;

        $config['uri_segment'] = 3;
        $config['use_page_numbers'] = FALSE;

        $this->pagination->initialize($config);

        // Menentukan halaman aktif
        $start = $this->uri->segment(3);

        if(!$start)
        {
            $start = 0;
        }

        $data['start'] = $start;

        // ===========================
        // DATA USER
        // ===========================


        $data['user'] = $this->User_model->getPagination(
            $config['per_page'],
            $start,
            $data['keyword']
        );


       //  $data['user'] = [];

        // Membuat Link Pagination
        $data['pagination'] = $this->pagination->create_links();

        // ===========================
        // LOAD VIEW
        // ===========================

        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('templates/topbar');
        $this->load->view('user/index', $data);
        $this->load->view('templates/footer');
        $this->load->view('templates/script');
    }

public function reset()
{
    $this->session->unset_userdata('keyword_user');

    redirect('user');
}

    public function tambah()
    {
        $data['title'] = 'Tambah User';

        // mengambil semua role
        $data['role'] = $this->db->get('tbl_role')->result();

        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('templates/topbar');
        $this->load->view('user/tambah', $data);
        $this->load->view('templates/footer');
        $this->load->view('templates/script');
    }

    public function insert()
    {
        $this->form_validation->set_rules('nama', 'Nama', 'required');
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('id_role', 'Role', 'required');

        if ($this->form_validation->run() == FALSE)
        {
            $this->tambah();
        }
        else
        {
            $data = [

                'id_role'   => $this->input->post('id_role'),
                'nama'      => $this->input->post('nama'),
                'username'  => $this->input->post('username'),
                'password'  => $this->input->post('password')

            ];

            $this->User_model->tambah($data);

            $this->session->set_flashdata(
                'message',

                '<div class="alert alert-success alert-dismissible fade show" role="alert">

                    Data User berhasil ditambahkan.

                    <button type="button"
                            class="close"
                            data-dismiss="alert">

                        <span>&times;</span>

                    </button>

                </div>'
            );

            redirect('user');
        }
    }

    public function edit($id)
    {
        $data['title'] = 'Edit User';

        $data['user'] = $this->User_model->getById($id);

        $data['role'] = $this->db->get('tbl_role')->result();

        $this->form_validation->set_rules('nama', 'Nama', 'required');
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('id_role', 'Role', 'required');

        if ($this->form_validation->run() == FALSE)
        {
            $this->load->view('templates/header');
            $this->load->view('templates/sidebar');
            $this->load->view('templates/topbar');
            $this->load->view('user/edit', $data);
            $this->load->view('templates/footer');
            $this->load->view('templates/script');
        }
        else
        {
            $this->User_model->update();

            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-success">
                    Data user berhasil diubah!
                </div>'
            );

            redirect('user');
        }
    }

    public function delete($id)
    {
        $this->User_model->delete($id);

        $this->session->set_flashdata(
            'message',
            '<div class="alert alert-success">
                Data user berhasil dihapus!
            </div>'
        );

        redirect('user');
    }

}