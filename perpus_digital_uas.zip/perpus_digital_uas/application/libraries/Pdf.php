<?php
defined('BASEPATH') OR exit('No direct script access allowed');

use Dompdf\Dompdf;
use Dompdf\Options;

class Pdf
{

    public $dompdf;

    public function __construct()
    {

        require_once APPPATH . '../vendor/autoload.php';

        $options = new Options();

        $options->set('isRemoteEnabled', true);

        $options->set('defaultFont', 'Arial');

        $this->dompdf = new Dompdf($options);

    }

}