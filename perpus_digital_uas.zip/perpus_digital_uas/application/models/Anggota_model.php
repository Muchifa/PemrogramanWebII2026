<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Anggota_model extends CI_Model
{

    private $table = 'tbl_anggota';

     /*
    ===================================
    TAMPIL DATA ANGGOTA
    ===================================
    */

    public function getAll()
    {
        return $this->db
                    // ->order_by('id_anggota', 'DESC'), sudah non aktif
                    ->get($this->table)
                    ->result();
    }


    /*
    ===================================
    INSERT DATA ANGGOTA
    ===================================
    */

    public function insert($data)
    {
        return $this->db->insert($this->table, $data);
    }

    /*
===================================
AMBIL DATA BERDASARKAN ID
===================================
*/

public function getById($id)
{
    return $this->db
                ->get_where($this->table, ['id_anggota' => $id])
                ->row();
}

/*
===================================
UPDATE DATA ANGGOTA
===================================
*/

public function update($id, $data)
{
    $this->db->where('id_anggota', $id);
    return $this->db->update($this->table, $data);
}

/*
===================================
HAPUS DATA ANGGOTA
===================================
*/

public function delete($id)
{
    $this->db->where('id_anggota', $id);
    return $this->db->delete($this->table);
}

public function countAll()
{
    return $this->db->count_all($this->table);
}

public function getPagination($limit, $start)
{
    return $this->db
        ->limit($limit, $start)
        ->get($this->table)
        ->result();
}

/*
===================================
SEARCH ANGGOTA
===================================
*/

public function search($keyword, $limit, $start)
{
    $this->db->like('nama_anggota', $keyword);
    $this->db->or_like('alamat', $keyword);

    return $this->db
                ->limit($limit, $start)
                ->get($this->table)
                ->result();
}


/*
===================================
HITUNG HASIL SEARCH
===================================
*/

public function countSearch($keyword)
{
    $this->db->like('nama_anggota', $keyword);
    $this->db->or_like('alamat', $keyword);

    return $this->db
                ->count_all_results($this->table);
}



}