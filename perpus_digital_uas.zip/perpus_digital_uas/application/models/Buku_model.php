<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Buku_model extends CI_Model
{
    private $table = 'tbl_buku';

    public function getAll()
{
    return $this->db
        ->select('b.*, k.nama_kategori, p.nama_penulis,
                   pb.nama_penerbit, r.nama_rak')
        ->from('tbl_buku b')
        ->join('tbl_kategori k', 'k.id_kategori = b.id_kategori')
        ->join('tbl_penulis p', 'p.id_penulis = b.id_penulis')
        ->join('tbl_penerbit pb', 'pb.id_penerbit = b.id_penerbit')
        ->join('tbl_rak r', 'r.id_rak = b.id_rak')
        ->get()
        ->result();
}

// Method Pengambilan Data dari tabel2 yang akan jadi relasi (kategori, penulis, penerbit, dan rak)

    public function getKategori()
{
    return $this->db->get('tbl_kategori')->result();
}

public function getPenulis()
{
    return $this->db->get('tbl_penulis')->result();
}

public function getPenerbit()
{
    return $this->db->get('tbl_penerbit')->result();
}

public function getRak()
{
    return $this->db->get('tbl_rak')->result();
}

// METHOD INSERT

public function insert($data)
{
    return $this->db->insert('tbl_buku', $data);
}

// METHOD GET BY ID

public function getById($id)
{

    return $this->db->get_where('tbl_buku', ['id_buku' => $id])->row();

}

// METHOD UPDATE

public function update($id, $data)
{
    $this->db->where('id_buku', $id);
    return $this->db->update($this->table, $data);
}

// METHOD DELETE

public function delete($id)
{
    $this->db->where('id_buku', $id);
    return $this->db->delete($this->table);
}

// METHOD  hitung semua

public function countAll()
{
    return $this->db->count_all($this->table);
}

// METHOD PAGINATION

public function getPagination($limit, $start)
{
    return $this->db
        ->select('b.*, k.nama_kategori, p.nama_penulis,
                  pb.nama_penerbit, r.nama_rak')
        ->from('tbl_buku b')
        ->join('tbl_kategori k', 'k.id_kategori = b.id_kategori')
        ->join('tbl_penulis p', 'p.id_penulis = b.id_penulis')
        ->join('tbl_penerbit pb', 'pb.id_penerbit = b.id_penerbit')
        ->join('tbl_rak r', 'r.id_rak = b.id_rak')
        ->limit($limit, $start)
        ->get()
        ->result();
}

public function search($keyword, $limit, $start)
{
    $this->db->select('b.*, k.nama_kategori, p.nama_penulis,
                        pb.nama_penerbit, r.nama_rak');
    $this->db->from('tbl_buku b');
    $this->db->join('tbl_kategori k', 'k.id_kategori = b.id_kategori');
    $this->db->join('tbl_penulis p', 'p.id_penulis = b.id_penulis');
    $this->db->join('tbl_penerbit pb', 'pb.id_penerbit = b.id_penerbit');
    $this->db->join('tbl_rak r', 'r.id_rak = b.id_rak');

    $this->db->group_start();
        $this->db->like('b.judul', $keyword);
        $this->db->or_like('b.isbn', $keyword);
        $this->db->or_like('k.nama_kategori', $keyword);
        $this->db->or_like('p.nama_penulis', $keyword);
        $this->db->or_like('pb.nama_penerbit', $keyword);
        $this->db->or_like('r.nama_rak', $keyword);
        $this->db->or_like('b.stok', $keyword);
        $this->db->or_like('b.status', $keyword);
    $this->db->group_end();

    return $this->db
                ->limit($limit, $start)
                ->get()
                ->result();
}

public function countSearch($keyword)
{
    $this->db->from('tbl_buku b');
    $this->db->join('tbl_kategori k', 'k.id_kategori = b.id_kategori');
    $this->db->join('tbl_penulis p', 'p.id_penulis = b.id_penulis');
    $this->db->join('tbl_penerbit pb', 'pb.id_penerbit = b.id_penerbit');
    $this->db->join('tbl_rak r', 'r.id_rak = b.id_rak');

    $this->db->group_start();
        $this->db->like('b.judul', $keyword);
        $this->db->or_like('b.isbn', $keyword);
        $this->db->or_like('k.nama_kategori', $keyword);
        $this->db->or_like('p.nama_penulis', $keyword);
        $this->db->or_like('pb.nama_penerbit', $keyword);
        $this->db->or_like('r.nama_rak', $keyword);
        $this->db->or_like('b.stok', $keyword);
        $this->db->or_like('b.status', $keyword);
    $this->db->group_end();

    return $this->db->count_all_results();
}

}