<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard_model extends CI_Model
{
	// METHOD UNTUK DASHBOARD

// method getTotalBuku()

	public function getTotalBuku()
	{
		return $this->db->count_all('tbl_buku');
	}

// method getTotalEbook()

	public function getTotalEbook()
	{
		return $this->db->count_all('tbl_ebook');
	}

// method getTotalAnggota()

	public function getTotalAnggota()
	{
		return $this->db->count_all('tbl_anggota');
	}

// method getTotalPeminjamanAktif()

	public function getTotalPeminjamanAktif()
{
    return $this->db
        ->where('status', 'Dipinjam')
        ->count_all_results('tbl_peminjaman');
}

public function getStatistikPeminjaman()
{
    $this->db->select('MONTH(tanggal_pinjam) AS bulan, COUNT(*) AS total');
    $this->db->from('tbl_peminjaman');
    $this->db->where('YEAR(tanggal_pinjam)', date('Y'));
    $this->db->group_by('MONTH(tanggal_pinjam)');
    $this->db->order_by('MONTH(tanggal_pinjam)', 'ASC');

    return $this->db->get()->result();
}

public function getStatusBuku()
{
    $tersedia = $this->db
        ->where('status', 'Tersedia')
        ->count_all_results('tbl_buku');

    $dipinjam = $this->db
        ->where('status', 'Dipinjam')
        ->count_all_results('tbl_buku');

    return [
        'tersedia' => $tersedia,
        'dipinjam' => $dipinjam
    ];
}

}