<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ebook_model extends CI_Model
{
    private $table = 'tbl_ebook';

    public function getAll()
{
    $this->db->select('e.*, b.judul');
    $this->db->from('tbl_ebook e');
    $this->db->join('tbl_buku b', 'b.id_buku = e.id_buku');
    return $this->db->get()->result();
}

    public function getBuku()
{
    return $this->db
        ->order_by('judul', 'ASC')
        ->get('tbl_buku')
        ->result();
}

public function insert($data)
{
    return $this->db->insert('tbl_ebook', $data);
}

public function getById($id)
{
    return $this->db
        ->where('id_ebook', $id)
        ->get('tbl_ebook')
        ->row();
}

public function update($id, $data)
{
    $this->db->where('id_ebook', $id);
    return $this->db->update('tbl_ebook', $data);
}

public function delete($id)
{
    return $this->db
        ->where('id_ebook', $id)
        ->delete('tbl_ebook');
}

public function countAll()
{
    return $this->db->count_all('tbl_ebook');
}

public function getPagination($limit, $start)
{
    $this->db->select('e.*, b.judul');
    $this->db->from('tbl_ebook e');
    $this->db->join('tbl_buku b', 'b.id_buku = e.id_buku');
    $this->db->limit($limit, $start);

    return $this->db->get()->result();
}

public function countSearch($keyword)
{
    $this->db->from('tbl_ebook e');
    $this->db->join('tbl_buku b', 'b.id_buku = e.id_buku');

    $this->db->group_start();
    $this->db->like('b.judul', $keyword);
    $this->db->or_like('e.file_pdf', $keyword);
    $this->db->group_end();

    return $this->db->count_all_results();
}

public function search($keyword, $limit, $start)
{
    $this->db->select('e.*, b.judul');
    $this->db->from('tbl_ebook e');
    $this->db->join('tbl_buku b', 'b.id_buku = e.id_buku');

    $this->db->group_start();
    $this->db->like('b.judul', $keyword);
    $this->db->or_like('e.file_pdf', $keyword);
    $this->db->group_end();

    $this->db->limit($limit, $start);

    return $this->db->get()->result();
}

}