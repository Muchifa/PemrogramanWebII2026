<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kategori_model extends CI_Model
{

    /*
    ===================================
    TAMPIL DATA KATEGORI
    ===================================
    */

    public function getAll()
    {
        return $this->db->get('tbl_kategori')->result();
    }

    /*
    ===================================
    INSERT DATA KATEGORI
    ===================================
    */

    public function insert($data)
    {
        return $this->db->insert('tbl_kategori', $data);
    }

    /*
===================================
AMBIL DATA BERDASARKAN ID
===================================
*/

public function getById($id)
{
    return $this->db
                ->get_where('tbl_kategori', ['id_kategori' => $id])
                ->row();
}

/*
===================================
UPDATE DATA KATEGORI
===================================
*/

public function update($id, $data)
{
    $this->db->where('id_kategori', $id);
    return $this->db->update('tbl_kategori', $data);
}

/*
===================================
HAPUS DATA KATEGORI
===================================
*/

public function delete($id)
{
    $this->db->where('id_kategori', $id);
    return $this->db->delete('tbl_kategori');
}

public function countAll()
{
    return $this->db->count_all('tbl_kategori');
}

public function getPagination($limit, $start)
{
    return $this->db
        ->limit($limit, $start)
        ->get('tbl_kategori')
        ->result();
}

/*
===================================
SEARCH KATEGORI
===================================
*/

public function search($keyword, $limit, $start)
{
    $this->db->like('nama_kategori', $keyword);

    return $this->db
                ->limit($limit, $start)
                ->get('tbl_kategori')
                ->result();
}


/*
===================================
HITUNG HASIL SEARCH
===================================
*/

public function countSearch($keyword)
{
    $this->db->like('nama_kategori', $keyword);

    return $this->db
                ->count_all_results('tbl_kategori');
}

}