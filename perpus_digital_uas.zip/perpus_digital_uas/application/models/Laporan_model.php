<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Laporan_model extends CI_Model
{

    public function getLaporanPeminjaman($tanggal_awal = null, $tanggal_akhir = null)
    {

        $this->db->select('
            pm.*,
            ag.nama_anggota,
            b.judul,
            d.jumlah,
            d.tanggal_kembali,
            d.denda
        ');

        $this->db->from('tbl_peminjaman pm');

        $this->db->join(
            'tbl_anggota ag',
            'ag.id_anggota = pm.id_anggota'
        );

        $this->db->join(
            'tbl_detail_pinjam d',
            'd.id_pinjam = pm.id_pinjam'
        );

        $this->db->join(
            'tbl_buku b',
            'b.id_buku = d.id_buku'
        );

        if (!empty($tanggal_awal) && !empty($tanggal_akhir))
        {

            $this->db->where(
                'pm.tanggal_pinjam >=',
                $tanggal_awal
            );

            $this->db->where(
                'pm.tanggal_pinjam <=',
                $tanggal_akhir
            );

        }

        $this->db->order_by(
            'pm.tanggal_pinjam',
            'DESC'
        );

        return $this->db->get()->result();

    }

}