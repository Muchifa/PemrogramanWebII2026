<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Peminjaman_model extends CI_Model
{
    private $table = 'tbl_peminjaman';
    // Method akan ditambahkan pada tahap berikutnya

    public function getAll()
{
    $this->db->select('p.*, a.nama_anggota, u.nama');
    $this->db->from('tbl_peminjaman p');
    $this->db->join('tbl_anggota a', 'a.id_anggota = p.id_anggota');
    $this->db->join('tbl_user u', 'u.id_user = p.id_user');

    return $this->db->get()->result();
}

public function getAnggota()
{
    return $this->db
        ->order_by('nama_anggota', 'ASC')
        ->get('tbl_anggota')
        ->result();
}

public function insert($data)
{
    $this->db->insert('tbl_peminjaman', $data);
}

public function delete($id)
{
    return $this->db->where('id_pinjam', $id)->delete('tbl_peminjaman');
}

public function getById($id)
{
    return $this->db
        ->where('id_pinjam', $id)
        ->get('tbl_peminjaman')
        ->row();
}

/*
public function getByNamaAnggota($nama_anggota)
{
    return $this->db
        ->where('nama_anggota', $nama_anggota)
        ->get('tbl_anggota')
        ->row();
}
*/

public function getDetailPinjam($id_pinjam)
{
    $this->db->select('d.*, b.judul');
    $this->db->from('tbl_detail_pinjam d');
    $this->db->join('tbl_buku b', 'b.id_buku = d.id_buku');
    $this->db->where('d.id_pinjam', $id_pinjam);

    return $this->db->get()->result();
}

public function getBuku()
{
    return $this->db
        ->where('stok >', 0)
        ->order_by('judul', 'ASC')
        ->get('tbl_buku')
        ->result();
}

public function getBukuById($id)
{
    return $this->db
        ->where('id_buku', $id)
        ->get('tbl_buku')
        ->row();
}

public function insertDetail($data)
{
    $this->db->insert('tbl_detail_pinjam', $data);
}

public function updateStok($id_buku, $jumlah)
{
    $this->db->set('stok', 'stok - '.$jumlah, false);
    $this->db->where('id_buku', $id_buku);
    $this->db->update('tbl_buku');
}

public function getDetailById($id_detail)
{
    return $this->db
        ->where('id_detail', $id_detail)
        ->get('tbl_detail_pinjam')
        ->row();
}

public function tambahStok($id_buku, $jumlah)
{
    $this->db->set('stok', 'stok + '.$jumlah, false);
    $this->db->where('id_buku', $id_buku);
    $this->db->update('tbl_buku');
}

public function hapusDetail($id_detail)
{
    $this->db->where('id_detail', $id_detail);
    $this->db->delete('tbl_detail_pinjam');
}

public function countDetail($id_pinjam)
{
    return $this->db
        ->where('id_pinjam', $id_pinjam)
        ->count_all_results('tbl_detail_pinjam');
}

public function countAll($keyword = null)
{
    $this->db->from('tbl_peminjaman p');
    $this->db->join('tbl_anggota a', 'a.id_anggota = p.id_anggota');

    if ($keyword) {
        $this->db->group_start();
        $this->db->like('a.nama_anggota', $keyword);
        $this->db->or_like('p.status', $keyword);
        $this->db->group_end();
    }

    return $this->db->count_all_results();
}

public function getPagination($limit, $start, $keyword = null)
{
    $this->db->select('p.*, a.nama_anggota, u.nama');
    $this->db->from('tbl_peminjaman p');
    $this->db->join('tbl_anggota a', 'a.id_anggota = p.id_anggota');
    $this->db->join('tbl_user u', 'u.id_user = p.id_user');

    if ($keyword) {
        $this->db->group_start();
        $this->db->like('a.nama_anggota', $keyword);
        $this->db->or_like('p.status', $keyword);
        $this->db->group_end();
    }

    $this->db->limit($limit, $start);

    return $this->db->get()->result();
}

}