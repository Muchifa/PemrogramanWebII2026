<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Penerbit_model extends CI_Model
{

    private $table = 'tbl_penerbit';

     /*
    ===================================
    TAMPIL DATA PENERBIT
    ===================================
    */

    public function getAll()
    {
        return $this->db
                   // ->order_by('id_penerbit', 'DESC')
                    ->get($this->table)
                    ->result();
    }


    /*
    ===================================
    INSERT DATA PENERBIT
    ===================================
    */

    public function insert($data)
    {
        return $this->db->insert($this->table, $data);
    }

    /*
===================================
AMBIL DATA BERDASARKAN ID
===================================
*/

public function getById($id)
{
    return $this->db
                ->get_where($this->table, ['id_penerbit' => $id])
                ->row();
}

/*
===================================
UPDATE DATA PENERBIT
===================================
*/

public function update($id, $data)
{
    $this->db->where('id_penerbit', $id);
    return $this->db->update($this->table, $data);
}

/*
===================================
HAPUS DATA PENERBIT
===================================
*/

public function delete($id)
{
    $this->db->where('id_penerbit', $id);
    return $this->db->delete($this->table);
}

public function countAll()
{
    return $this->db->count_all($this->table);
}

public function getPagination($limit, $start)
{
    return $this->db
        ->limit($limit, $start)
        ->get($this->table)
        ->result();
}

/*
===================================
SEARCH PENERBIT
===================================
*/

public function search($keyword, $limit, $start)
{
    $this->db->like('nama_penerbit', $keyword);
    $this->db->or_like('alamat', $keyword);

    return $this->db
                ->limit($limit, $start)
                ->get($this->table)
                ->result();
}


/*
===================================
HITUNG HASIL SEARCH
===================================
*/

public function countSearch($keyword)
{
    $this->db->like('nama_penerbit', $keyword);

    return $this->db
                ->count_all_results($this->table);
}



}