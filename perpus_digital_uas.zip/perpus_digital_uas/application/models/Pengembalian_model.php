<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pengembalian_model extends CI_Model
{
    private $table = 'tbl_pengembalian';
    // Method akan ditambahkan pada tahap berikutnya
    public function getAll()
{
    $this->db->select('p.id_pinjam,
                        a.nama_anggota,
                        p.tanggal_pinjam,
                        p.tanggal_jatuh_tempo,
                        p.status');
    $this->db->from('tbl_peminjaman p');
    $this->db->join('tbl_anggota a', 'a.id_anggota = p.id_anggota');
    $this->db->join(
        'tbl_detail_pinjam d',
        'd.id_pinjam = p.id_pinjam'
    );
    $this->db->where('d.tanggal_kembali IS NULL', null, false);
    $this->db->group_by('p.id_pinjam');

    return $this->db->get()->result();
}

public function getDetailBelumKembali($id_pinjam)
{
    $this->db->select('d.*, b.judul');
    $this->db->from('tbl_detail_pinjam d');
    $this->db->join('tbl_buku b', 'b.id_buku = d.id_buku');
    $this->db->where('d.id_pinjam', $id_pinjam);
    $this->db->where('d.tanggal_kembali IS NULL', null, false);

    return $this->db->get()->result();
}

public function kembalikanDetail($id_detail)
{
    $this->db->set('tanggal_kembali', date('Y-m-d'));
    $this->db->where('id_detail', $id_detail);
    $this->db->update('tbl_detail_pinjam');
}

public function countBelumKembali($id_pinjam)
{
    return $this->db
        ->where('id_pinjam', $id_pinjam)
        ->where('tanggal_kembali IS NULL', null, false)
        ->count_all_results('tbl_detail_pinjam');
}

public function setSelesai($id_pinjam)
{
    $this->db->where('id_pinjam', $id_pinjam);
    $this->db->update('tbl_peminjaman', [
        'status' => 'Selesai'
    ]);
}

public function setPengembalian($id_detail, $tanggal_kembali, $denda)
{
    $this->db->where('id_detail', $id_detail);
    $this->db->update('tbl_detail_pinjam', [
        'tanggal_kembali' => $tanggal_kembali,
        'denda'           => $denda
    ]);
}

public function countAll($keyword = null)
{
    $this->db->from('tbl_peminjaman p');
    $this->db->join('tbl_anggota a', 'a.id_anggota = p.id_anggota');
    $this->db->join('tbl_detail_pinjam d', 'd.id_pinjam = p.id_pinjam');

    $this->db->where('d.tanggal_kembali IS NULL', null, false);

    if ($keyword) {
        $this->db->group_start();
        $this->db->like('a.nama_anggota', $keyword);
        $this->db->or_like('p.status', $keyword);
        $this->db->group_end();
    }

    $this->db->group_by('p.id_pinjam');

    return $this->db->get()->num_rows();
}

public function getPagination($limit, $start, $keyword = null)
{
    $this->db->select(
        'p.id_pinjam, a.nama_anggota,
         p.tanggal_pinjam, p.tanggal_jatuh_tempo,
         p.status'
    );
    $this->db->from('tbl_peminjaman p');
    $this->db->join('tbl_anggota a', 'a.id_anggota = p.id_anggota');
    $this->db->join('tbl_detail_pinjam d', 'd.id_pinjam = p.id_pinjam');

    $this->db->where('d.tanggal_kembali IS NULL', null, false);

    if ($keyword) {
        $this->db->group_start();
        $this->db->like('a.nama_anggota', $keyword);
        $this->db->or_like('p.status', $keyword);
        $this->db->group_end();
    }

    $this->db->group_by('p.id_pinjam');
    $this->db->limit($limit, $start);

    return $this->db->get()->result();
}

}