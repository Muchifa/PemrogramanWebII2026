<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Penulis_model extends CI_Model
{

    private $table = 'tbl_penulis';

     /*
    ===================================
    TAMPIL DATA PENULIS
    ===================================
    */

    public function getAll()
    {
        return $this->db
                    // ->order_by('id_penulis', 'DESC')
                    ->get($this->table)
                    ->result();
    }


    /*
    ===================================
    INSERT DATA penulis
    ===================================
    */

    public function insert($data)
    {
        return $this->db->insert($this->table, $data);
    }

    /*
===================================
AMBIL DATA BERDASARKAN ID
===================================
*/

public function getById($id)
{
    return $this->db
                ->get_where($this->table, ['id_penulis' => $id])
                ->row();
}

/*
===================================
UPDATE DATA penulis
===================================
*/

public function update($id, $data)
{
    $this->db->where('id_penulis', $id);
    return $this->db->update($this->table, $data);
}

/*
===================================
HAPUS DATA penulis
===================================
*/

public function delete($id)
{
    $this->db->where('id_penulis', $id);
    return $this->db->delete($this->table);
}

public function countAll()
{
    return $this->db->count_all($this->table);
}

public function getPagination($limit, $start)
{
    return $this->db
        ->limit($limit, $start)
        ->get($this->table)
        ->result();
}

/*
===================================
SEARCH penulis
===================================
*/

public function search($keyword, $limit, $start)
{
    $this->db->like('nama_penulis', $keyword);

    return $this->db
                ->limit($limit, $start)
                ->get($this->table)
                ->result();
}


/*
===================================
HITUNG HASIL SEARCH
===================================
*/

public function countSearch($keyword)
{
    $this->db->like('nama_penulis', $keyword);

    return $this->db
                ->count_all_results($this->table);
}



}