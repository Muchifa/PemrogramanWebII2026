<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Rak_model extends CI_Model
{

    private $table = 'tbl_rak';

     /*
    ===================================
    TAMPIL DATA RAK
    ===================================
    */

    public function getAll()
    {
        return $this->db
                    // ->order_by('id_rak', 'DESC')
                    ->get($this->table)
                    ->result();
    }


    /*
    ===================================
    INSERT DATA RAK
    ===================================
    */

    public function insert($data)
    {
        return $this->db->insert($this->table, $data);
    }

    /*
===================================
AMBIL DATA BERDASARKAN ID
===================================
*/

public function getById($id)
{
    return $this->db
                ->get_where($this->table, ['id_rak' => $id])
                ->row();
}

/*
===================================
UPDATE DATA RAK
===================================
*/

public function update($id, $data)
{
    $this->db->where('id_rak', $id);
    return $this->db->update($this->table, $data);
}

/*
===================================
HAPUS DATA RAK
===================================
*/

public function delete($id)
{
    $this->db->where('id_rak', $id);
    return $this->db->delete($this->table);
}

public function countAll()
{
    return $this->db->count_all($this->table);
}

public function getPagination($limit, $start)
{
    return $this->db
        ->limit($limit, $start)
        ->get($this->table)
        ->result();
}

/*
===================================
SEARCH RAK
===================================
*/

public function search($keyword, $limit, $start)
{
    $this->db->like('nama_rak', $keyword);
    $this->db->or_like('lokasi', $keyword);

    return $this->db
                ->limit($limit, $start)
                ->get($this->table)
                ->result();
}


/*
===================================
HITUNG HASIL SEARCH
===================================
*/

public function countSearch($keyword)
{
    $this->db->like('nama_rak', $keyword);

    return $this->db
                ->count_all_results($this->table);
}



}