<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Role_model extends CI_Model {

    private $table = 'tbl_role';

    public function getAll()
    {
        return $this->db->get($this->table)->result();
    }

    public function getById($id)
{
    return $this->db
                ->get_where($this->table,
                            ['id_role'=>$id])
                ->row();
}

public function insert()
{
    $data = [
        'nama_role' => $this->input->post('nama_role')
    ];

    $this->db->insert(
        $this->table,
        $data
    );
}

public function update()
{
    $data = [
        'nama_role' => $this->input->post('nama_role')
    ];

    $this->db->where(
        'id_role',
        $this->input->post('id_role')
    );

    $this->db->update(
        $this->table,
        $data
    );
}

public function delete($id)
{
    $this->db->where(
        'id_role',
        $id
    );

    $this->db->delete(
        $this->table
    );
}

public function cari()
{
    $keyword = $this->input->post('keyword');

    $this->db->like(
        'nama_role',
        $keyword
    );

    return $this->db
                ->get($this->table)
                ->result();
}

public function jumlah()
{

    return $this->db->count_all($this->table);
}

public function getPagination(
    $limit,
    $start,
    $keyword = null
)
{
    if($keyword)
    {
        $this->db->like(
            'nama_role',
            $keyword
        );
    }

    return $this->db
                ->get(
                    $this->table,
                    $limit,
                    $start
                )
                ->result();
}

public function jumlahCari($keyword)
{
    if($keyword)
    {
        $this->db->like(
            'nama_role',
            $keyword
        );
    }

    return $this->db
                ->count_all_results(
                    $this->table
                );
}

}