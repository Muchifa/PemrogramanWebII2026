<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {

    private $table = 'tbl_user';

    public function getAll()
{
    $this->db->select('
        tbl_user.*,
        tbl_role.nama_role
    ');

    $this->db->from('tbl_user');

    $this->db->join(
        'tbl_role',
        'tbl_role.id_role = tbl_user.id_role'
    );

    return $this->db->get()->result();
}

public function tambah($data)
{
    return $this->db->insert(
        'tbl_user',
        $data
    );
}

public function getById($id)
{
    return $this->db
                ->get_where(
                    'tbl_user',
                    ['id_user' => $id]
                )
                ->row();
}

public function update()
{
    $data = [

        'nama'      => $this->input->post('nama'),

        'username'  => $this->input->post('username'),

        'password'  => $this->input->post('password'),

        'id_role'   => $this->input->post('id_role')

    ];

    $this->db->where(
        'id_user',
        $this->input->post('id_user')
    );

    $this->db->update(
        $this->table,
        $data
    );
}

public function delete($id)
{
    $this->db->where('id_user', $id);

    $this->db->delete($this->table);
}

/*
public function cari()
{
    $keyword = $this->input->post('keyword');

    $this->db->select('tbl_user.*, tbl_role.nama_role');

    $this->db->from('tbl_user');

    $this->db->join(
        'tbl_role',
        'tbl_role.id_role = tbl_user.id_role'
    );

    $this->db->like(
        'nama',
        $keyword
    );

    $this->db->or_like(
        'username',
        $keyword
    );

    return $this->db->get()->result();
}
*/

public function jumlah($keyword = null)
{
    
    $this->db->from('tbl_user');

    if($keyword)
    {
        $this->db->group_start();

        $this->db->like('nama', $keyword);

        $this->db->or_like('username', $keyword);

        $this->db->group_end();
    }

    return $this->db->count_all_results();

    // return 0;
}

public function getPagination($limit, $start, $keyword = null)
{
    $this->db->select(
        'tbl_user.*, tbl_role.nama_role'
    );

    $this->db->from('tbl_user');

    $this->db->join(
        'tbl_role',
        'tbl_role.id_role = tbl_user.id_role'
    );

    if($keyword)
    {
        $this->db->group_start();

        $this->db->like('nama', $keyword);

        $this->db->or_like('username', $keyword);

        $this->db->group_end();
    }

    $this->db->limit($limit, $start);

    return $this->db->get()->result();

}

public function cekUsername($username)
{
    return $this->db->get_where('tbl_user', ['username' => $username])
                ->row();
}

}