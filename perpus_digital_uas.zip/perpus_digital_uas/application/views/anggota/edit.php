<div class="container-fluid">

    <h1 class="h3 mb-4 text-gray-800">

        Edit Anggota

    </h1>

    <div class="card shadow mb-4">

        <div class="card-body">

            <form method="post"
      action="<?= base_url('anggota/edit/'.$anggota->id_anggota); ?>">

                <div class="form-group">

    <label>Nama Anggota</label>

    <input type="text"name="nama_anggota"class="form-control"
        value="<?= set_value('nama_anggota', $anggota->nama_anggota); ?>"
        placeholder="Masukkan Nama Anggota">

    <?= form_error('nama_anggota','<small class="text-danger">','</small>'); ?>

               </div>

               <div class="form-group">

    <label>Alamat Pengguna</label>

    <input type="text"name="alamat"class="form-control"
        value="<?= set_value('alamat', $anggota->alamat); ?>"
        placeholder="Masukkan Alamat Anggota">

    <?= form_error('alamat','<small class="text-danger">','</small>'); ?>

               </div>

               <div class="form-group">

    <label>No Telp Pengguna</label>

    <input type="text"name="telepon"class="form-control"
        value="<?= set_value('telepon', $anggota->telepon); ?>"
        placeholder="Masukkan No Telp Anggota">

    <?= form_error('telepon','<small class="text-danger">','</small>'); ?>

               </div>

               <div class="form-group">

    <label>Email Pengguna</label>

    <input type="text"name="email"class="form-control"
        value="<?= set_value('email', $anggota->email); ?>"
        placeholder="Masukkan Email Anggota">

    <?= form_error('email','<small class="text-danger">','</small>'); ?>

               </div>

               <div class="form-group">
                     <label>Foto</label>
                     <input type="file" name="foto" class="form-control-file">
                 </div>

                 <!-- Foto opsional -->


                <button class="btn btn-primary">

                    Simpan

                </button>

                <a href="<?= base_url('anggota'); ?>"
                   class="btn btn-secondary">

                    Kembali

                </a>

            </form>

        </div>

    </div>

</div>