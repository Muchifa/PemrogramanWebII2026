<div class="container-fluid">
    
    <h1 class="h3 mb-4 text-gray-800">
        Data Anggota
    </h1>

     <?= $this->session->flashdata('message'); ?>

    <div class="card shadow mb-4">

        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">
                Master Data Anggota
            </h6>
        </div>

        <div class="card-body">

            <!-- Tombol Tambah + Search -->

<div class="row mb-3">

    <!-- Tombol Tambah -->
    <div class="col-md-6">

        <a href="<?= base_url('anggota/tambah'); ?>"
           class="btn btn-primary">

            <i class="fas fa-plus"></i>
            Tambah Anggota

        </a>

    </div>

    <!-- Form Search -->
    <div class="col-md-6">

        <form method="post"
              action="<?= base_url('anggota'); ?>">

            <div class="input-group">

                <input
                    type="text"
                    name="keyword"
                    class="form-control"
                    placeholder="Cari anggota..."
                    value="<?= $keyword; ?>">

                <div class="input-group-append">

                    <button
                        class="btn btn-primary"
                        type="submit">

                        <i class="fas fa-search"></i>
                        Search

                    </button>

                    <a href="<?= base_url('anggota/reset'); ?>"
                         class="btn btn-secondary">
                         <i class="fas fa-sync"></i>
                             Reset
                      </a>

                </div>

            </div>

        </form>

    </div>

</div>

            <table class="table table-bordered">

                <thead>

                    <tr>

                        <th width="70">No</th>
                        <th>Nama Anggota</th>
                        <th>Alamat</th>
                        <th>No Telp Anggota</th>
                        <th>Email</th>
                        <!--th>Foto</th--> <!-- Foto belum diperlukan  -->
                        <th>Aksi</th>

                    </tr>

                </thead>

                <tbody>

                <?php if (empty($anggota)) : ?>

                    <tr>

                        <td colspan="5" class="text-center text-muted">

                            Belum ada data anggota.

                        </td>

                    </tr>

                <?php else : ?>

                    <?php
                    $no = $start + 1;
                    foreach ($anggota as $ag) :
                    ?>

                    <tr>

                        <td><?= $no++; ?></td>

                        <td><?= $ag->nama_anggota; ?></td>
                        <td><?= $ag->alamat; ?></td>
                        <td><?= $ag->telepon; ?></td>
                        <td><?= $ag->email; ?></td>
                        <!--td><?= $ag->foto; ?></td--> <!-- foto belum diperlukan -->

                        <td>

    <a href="<?= base_url('anggota/edit/'.$ag->id_anggota); ?>"
       class="btn btn-warning btn-sm">

        <i class="fas fa-edit"></i>

    </a>

    <a href="<?= base_url('anggota/hapus/'.$ag->id_anggota); ?>"
       class="btn btn-danger btn-sm"
       onclick="return confirm('Yakin ingin menghapus data ini?')">

        <i class="fas fa-trash"></i>

    </a>

</td>

                    </tr>

                    <?php endforeach; ?>

                <?php endif; ?>

                </tbody>

            </table>

            <?= $pagination; ?>

        </div>

    </div>

</div>