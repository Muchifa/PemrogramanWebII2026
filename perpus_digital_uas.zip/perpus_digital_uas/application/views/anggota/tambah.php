<div class="container-fluid">

    <h1 class="h3 mb-4 text-gray-800">

        Tambah Anggota

    </h1>

    <div class="card shadow mb-4">

        <div class="card-header py-3">

            <h6 class="m-0 font-weight-bold text-primary">

                Form Tambah Anggota

            </h6>

        </div>

        <div class="card-body">

            <form method="post">

                <div class="form-group">

                    <label>Nama Anggota</label>

            <input type="text"name="nama_anggota"class="form-control"placeholder="Masukkan Nama Anggota">
              <?= form_error('nama_anggota','<small class="text-danger">','</small>'); ?>

                </div>

                <div class="form-group">

                    <label>Alamat Anggota</label>

            <input type="text"name="alamat"class="form-control"placeholder="Masukkan Alamat Anggota">
              <?= form_error('alamat','<small class="text-danger">','</small>'); ?>

                </div>

                <div class="form-group">

                    <label>No Telp Anggota</label>

            <input type="text"name="telepon"class="form-control"placeholder="Masukkan No Telp Anggota">
              <?= form_error('telepon','<small class="text-danger">','</small>'); ?>

                </div>

                <div class="form-group">

                    <label>Email Anggota</label>

            <input type="text"name="email"class="form-control"placeholder="Masukkan Email Anggota">
              <?= form_error('email','<small class="text-danger">','</small>'); ?>

                </div>

                <div class="form-group">
                     <label>Foto</label>
                     <input type="file" name="foto" class="form-control-file">
                 </div>


                <button type="submit"
                        class="btn btn-primary">

                    Simpan

                </button>

                <a href="<?= base_url('anggota'); ?>"
                   class="btn btn-secondary">

                    Kembali

                </a>

            </form>

        </div>

    </div>

</div>