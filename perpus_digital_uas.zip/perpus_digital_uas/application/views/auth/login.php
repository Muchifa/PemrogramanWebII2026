<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1">

    <title>

        PERPUS DIGITAL

    </title>

    <link
        rel="stylesheet"
        href="<?= base_url('assets/css/login.css'); ?>">

</head>

<body>

<div class="login-container">

    <div class="login-box">

        <?= $this->session->flashdata('message'); ?>

        <h1>

            LOGIN

        </h1>

        <p>

            PERPUSTAKAAN DIGITAL

            <br>

            UAS 2026

        </p>

        <form
            method="post"
            action="<?= base_url('auth/login'); ?>">

            <!--input type="text"name="username"placeholder="Username"autocomplete="off"required-->

            <input type="text"name="username"placeholder="Username"required>

            <input type="password"name="password"placeholder="Password"required>

            <button type="submit">

                Login

            </button>

        </form>

        <p id="hasil">

            <?php
            if(isset($error))
            {
                echo $error;
            }
            ?>

        </p>

        <div class="footer">

            © 2026

            Perpus Digital

        </div>

    </div>

</div>

</body>

</html>