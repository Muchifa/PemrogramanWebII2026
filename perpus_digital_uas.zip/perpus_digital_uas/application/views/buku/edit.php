<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800">Edit Buku</h1>

    <form method="post">

        <div class="form-group">
             <label>ISBN</label>
              <input type="text" name="isbn" class="form-control"
           value="<?= set_value('isbn', $buku->isbn); ?>">
        </div>

        <?= form_error('isbn', '<small class="text-danger">', '</small>'); ?>


        <div class="form-group">
            <label>Judul Buku</label>
            <input type="text" class="form-control" name="judul"
            value="<?= set_value('judul', $buku->judul); ?>">
        </div>

        <?= form_error('judul', '<small class="text-danger">', '</small>'); ?>


        <div class="form-group">

             <label>Kategori</label>
               <select name="id_kategori" class="form-control">
              <option value="">-- Pilih Kategori --</option>

            <?php foreach ($kategori as $k) : ?>
            <option value="<?= $k->id_kategori; ?>"
                <?= set_select('id_kategori',$k->id_kategori,$k->id_kategori == $buku->id_kategori); ?>>
                <?= $k->nama_kategori; ?>
            </option>
             <?php endforeach; ?>
             </select>
             <?= form_error('id_kategori', '<small class="text-danger">', '</small>'); ?>
        </div>

        <div class="form-group">

             <label>Penulis</label>
               <select name="id_penulis" class="form-control">
              <option value="">-- Pilih Penulis --</option>

            <?php foreach ($penulis as $p) : ?>
            <option value="<?= $p->id_penulis; ?>"
                 <?= set_select('id_penulis',$p->id_penulis,$p->id_penulis == $buku->id_penulis); ?>>
                 <?= $p->nama_penulis; ?>
             </option>
             <?php endforeach; ?>
             </select>
             <?= form_error('id_penulis', '<small class="text-danger">', '</small>'); ?>
        </div>

        <div class="form-group">

             <label>Penerbit</label>
               <select name="id_penerbit" class="form-control">
              <option value="">-- Pilih Penerbit --</option>

            <?php foreach ($penerbit as $pb) : ?>
            <option value="<?= $pb->id_penerbit; ?>"
                 <?= set_select('id_penerbit',$pb->id_penerbit,$pb->id_penerbit == $buku->id_penerbit); ?>>
                 <?= $pb->nama_penerbit; ?>
             </option>
             <?php endforeach; ?>
             </select>
             <?= form_error('id_penerbit', '<small class="text-danger">', '</small>'); ?>
        </div>

        <div class="form-group">

             <label>Rak</label>
               <select name="id_rak" class="form-control">
              <option value="">-- Pilih Rak --</option>

            <?php foreach ($rak as $rk) : ?>
            <option value="<?= $rk->id_rak; ?>"
                 <?= set_select('id_rak',$rk->id_rak,$rk->id_rak == $buku->id_rak); ?>>
                 <?= $rk->nama_rak; ?>
             </option>
             <?php endforeach; ?>
             </select>
             <?= form_error('id_rak', '<small class="text-danger">', '</small>'); ?>
        </div>

        <div class="form-group">
    <label>Tahun Terbit</label>
    <input type="number" name="tahun_terbit" class="form-control"
           min="1900" max="<?= date('Y'); ?>"
           value="<?= set_value('tahun_terbit', $buku->tahun_terbit); ?>">
</div>

<?= form_error('tahun_terbit', '<small class="text-danger">', '</small>'); ?>

<div class="form-group">
    <label>Stok</label>
    <input type="number" name="stok" class="form-control"
           min="0" value="<?= set_value('stok', $buku->stok); ?>">
</div>

<?= form_error('stok', '<small class="text-danger">', '</small>'); ?>

<div class="form-group">
    <label>Cover</label>
    <input type="file" name="cover" class="form-control-file">
</div>

<!--?= form_error('cover', '<small class="text-danger">', '</small>'); ?-->

<div class="form-group">
    <label>Deskripsi</label>
    <textarea name="deskripsi" class="form-control"><?= set_value('deskripsi', $buku->deskripsi); ?></textarea>
</div>

<?= form_error('deskripsi', '<small class="text-danger">', '</small>'); ?>

<div class="form-group">
    <label>Status</label>
    <select name="status" class="form-control">
        <option value="">--Plilh Status--</option>
        <option value="Tersedia"<?= set_select('status', 'Tersedia', $buku->status == 'Tersedia'); ?>>
             Tersedia
        </option>

        <option value="Tidak Tersedia"<?= set_select('status', 'Tidak Tersedia', $buku->status == 'Tidak Tersedia'); ?>>
               Tidak Tersedia
        </option>
    </select>
</div>

<?= form_error('status', '<small class="text-danger">', '</small>'); ?>

<div class="container-fluid">

        <button type="submit" class="btn btn-primary">
            Simpan
        </button>

        <a href="<?= base_url('buku'); ?>"
           class="btn btn-secondary">
            Kembali
        </a>

</div>
    </form>
</div>