<div class="container-fluid">

    <h1 class="h3 mb-4 text-gray-800">
        Data Buku
    </h1>

    <?= $this->session->flashdata('message'); ?>

    <div class="card shadow mb-4">

        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">
                Master Data Buku
            </h6>
        </div>

        <div class="card-body">

            <!--p>Total Buku: <?= count($buku); ?></p-->

            <!-- Tombol Tambah + Search -->

<div class="row mb-3">

    <!-- Tombol Tambah -->
    <div class="col-md-6">

        <a href="<?= base_url('buku/tambah'); ?>"
           class="btn btn-primary">

            <i class="fas fa-plus"></i>
            Tambah Buku

        </a>

    </div>

    <!-- Form Search -->
    <div class="col-md-6">

        <form method="post"
              action="<?= base_url('buku'); ?>">

            <div class="input-group">

                <input
                    type="text"
                    name="keyword"
                    class="form-control"
                    placeholder="Cari buku..."
                    value="<?= $keyword; ?>">

                <div class="input-group-append">

                    <button
                        class="btn btn-primary"
                        type="submit">

                        <i class="fas fa-search"></i>
                        Search

                    </button>

                    <a href="<?= base_url('buku/reset'); ?>"
                         class="btn btn-secondary">
                         <i class="fas fa-sync"></i>
                             Reset
                      </a>

                </div>

            </div>

        </form>

    </div>

</div>

            <table class="table table-bordered">
    <thead>
        <tr>
            <th width="70">No</th>
            <th>Judul Buku</th>
            <th>Kategori</th>
            <th>Penulis</th>
            <th>Penerbit</th>
            <th>Rak</th>
            <th>Stok</th>
            <th>Status</th>
            <th>Aksi</th>
        </tr>
    </thead>

    <tbody>
    <?php if (empty($buku)) : ?>
        <tr>
            <td colspan="9" class="text-center text-muted">
                Belum ada data buku.
            </td>
        </tr>

         <?php else : ?>

                    <?php
                    $no = $start + 1;
                    foreach ($buku as $b) :
                    ?>

                    <tr>

                        <td><?= $no++; ?></td>

                        <td><?= $b->judul; ?></td>
                        <td><?= $b->nama_kategori; ?></td>
                        <td><?= $b->nama_penulis; ?></td>
                        <td><?= $b->nama_penerbit; ?></td>
                        <td><?= $b->nama_rak; ?></td>
                        <td><?= $b->stok; ?></td>
                        <td><?= $b->status; ?></td>

                        <td>

    <a href="<?= base_url('buku/edit/'.$b->id_buku); ?>"
       class="btn btn-warning btn-sm">

        <i class="fas fa-edit"></i>

    </a>

    <a href="<?= base_url('buku/hapus/'.$b->id_buku); ?>"
       class="btn btn-danger btn-sm"
       onclick="return confirm('Yakin ingin menghapus data ini?')">

        <i class="fas fa-trash"></i>

    </a>

</td>

                    </tr>

                    <?php endforeach; ?>
    <?php endif; ?>

    </tbody>
</table>

<?= $pagination; ?>

        </div>

    </div>

</div>