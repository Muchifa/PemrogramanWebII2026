<!-- Begin Page Content -->
                <div class="container-fluid">

                    <?= $this->session->flashdata('message'); ?>

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Dashboard Perpustakaan Digital</h1>
                        <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                                class="fas fa-home fa-sm text-white-50"></i> Dashboard Perpustakaan</a>
                    </div>

                    <!-- Alert Login -->

                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                          <strong>
                              Selamat datang,<?= $this->session->userdata('nama'); ?>
                          </strong>

                         <br>

                          Anda berhasil login ke Sistem Informasi Perpustakaan Digital.

                          <button
                              type="button"
                              class="close"
                              data-dismiss="alert">

                              <span>&times;</span>

                         </button>
                     </div>

                     <div class="alert alert-info">
                         <strong>User Login :</strong>
                         <?= $this->session->userdata('username'); ?>
                     </div>

                     <div class="alert alert-warning">


<?php

if($this->session->userdata('id_role') == ROLE_ADMIN)
{
    echo "Anda Login Sebagai Administrator";
}

elseif($this->session->userdata('id_role') == ROLE_PETUGAS)
{
    echo "Anda Login Sebagai Petugas";
}

elseif($this->session->userdata('id_role') == ROLE_ANGGOTA)
{
    echo "Anda Login Sebagai Anggota";
}

?>

</div>

<hr>

                    <!-- Content Row -->
                    <div class="row">

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                Total Buku</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $total_buku; ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-book fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                Total E-Book</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $total_ebook; ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-file-pdf fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-info shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Total Anggota
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800"><?= $total_anggota; ?></div>
                                                </div>
                                                <div class="col">
                                                    <div class="progress progress-sm mr-2">
                                                        <div class="progress-bar bg-info" role="progressbar"
                                                            style="width: 50%" aria-valuenow="50" aria-valuemin="0"
                                                            aria-valuemax="100"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Pending Requests Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-warning shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                                Total Peminjaman</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $total_peminjaman_aktif; ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-exchange-alt fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Content Row -->

                    <div class="row">

                        <!-- Area Chart -->
                        <div class="col-xl-8 col-lg-7">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Statistik Peminjaman</h6>
                                    <div class="dropdown no-arrow">
                                        <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink"
                                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in"
                                            aria-labelledby="dropdownMenuLink">
                                            <div class="dropdown-header">Dropdown Header:</div>
                                            <a class="dropdown-item" href="#">Action</a>
                                            <a class="dropdown-item" href="#">Another action</a>
                                            <div class="dropdown-divider"></div>
                                            <a class="dropdown-item" href="#">Something else here</a>
                                        </div>
                                    </div>
                                </div>
                                <!-- Card Body -->
                                <div class="card-body">
                                    <div class="chart-area">
                                        <canvas id="myAreaChart"></canvas>

                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Pie Chart -->
                        <div class="col-xl-4 col-lg-5">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Distribusi Status Buku</h6>
                                    <div class="dropdown no-arrow">
                                        <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink"
                                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in"
                                            aria-labelledby="dropdownMenuLink">
                                            <div class="dropdown-header">Dropdown Header:</div>
                                            <a class="dropdown-item" href="#">Action</a>
                                            <a class="dropdown-item" href="#">Another action</a>
                                            <div class="dropdown-divider"></div>
                                            <a class="dropdown-item" href="#">Something else here</a>
                                        </div>
                                    </div>
                                </div>
                                <!-- Card Body -->
                                <div class="card-body">
                                    <div class="chart-pie pt-3 pb-3">
                                        <canvas id="myPieChart"></canvas>
                                    </div>
                                    <div class="mt-4 text-center small">

    <span class="mr-3">

        <i class="fas fa-circle text-success"></i>

        Tersedia
        (<?= $status_buku['tersedia']; ?>)

    </span>

    <span>

        <i class="fas fa-circle text-danger"></i>

        Dipinjam
        (<?= $status_buku['dipinjam']; ?>)

    </span>

</div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Content Row -->
                    <div class="row">

                        <!-- Content Column -->
                        <div class="col-lg-6 mb-4">

                            <!-- Project Card Example -->
                            

                            <!-- Color System -->
                            <div class="card shadow">

    <div class="card-header py-3">

        <h6 class="m-0 font-weight-bold text-primary">

            Ringkasan Sistem

        </h6>

    </div>

    <div class="card-body">

        <table class="table table-borderless table-sm">

            <tr>

                <td width="45%"><strong>Total Buku</strong></td>

                <td>: <?= $total_buku; ?></td>

            </tr>

            <tr>

                <td><strong>Total E-Book</strong></td>

                <td>: <?= $total_ebook; ?></td>

            </tr>

            <tr>

                <td><strong>Total Anggota</strong></td>

                <td>: <?= $total_anggota; ?></td>

            </tr>

            <tr>

                <td><strong>Total Peminjaman</strong></td>

                <td>: <?= $total_peminjaman_aktif; ?></td>

            </tr>

            <tr>

                <td><strong>Framework</strong></td>

                <td>: CodeIgniter 3</td>

            </tr>

            <tr>

                <td><strong>Template</strong></td>

                <td>: SB Admin 2</td>

            </tr>

            <tr>

                <td><strong>Database</strong></td>

                <td>: MySQL</td>

            </tr>

            <tr>

                <td><strong>Tahun</strong></td>

                <td>: <?= date('Y'); ?></td>

            </tr>

        </table>

    </div>

</div>

                        </div>

                        <div class="col-lg-6 mb-4">

                            <!-- Illustrations -->
                            <div class="card shadow mb-4">

    <div class="card-header py-3">

        <h6 class="m-0 font-weight-bold text-primary">

            Panduan Penggunaan Sistem

        </h6>

    </div>

    <div class="card-body">

        <p>

            Selamat datang di
            <strong>Sistem Informasi Perpustakaan Digital</strong>.

        </p>

        <hr>

        <ol class="mb-0">

            <li>
                Kelola data master seperti
                Role, User, Kategori, Penulis,
                Penerbit, Rak, Buku, E-Book,
                dan Anggota.
            </li>

            <li class="mt-2">
                Lakukan transaksi
                peminjaman dan pengembalian
                buku.
            </li>

            <li class="mt-2">
                Gunakan menu laporan
                untuk melihat data transaksi.
            </li>

            <li class="mt-2">
                Dashboard akan selalu
                menampilkan statistik terbaru
                berdasarkan data pada database.
            </li>

        </ol>

    </div>

</div>

                            <!-- Approach -->
                            <div class="card-body">

    <table class="table table-borderless table-sm">

        <tr>

            <td width="40%"><strong>Nama Aplikasi</strong></td>

            <td>: Sistem Informasi Perpustakaan Digital</td>

        </tr>

        <tr>
    <th>Kelompok</th>
    <td>:</td>
    <td>

        <div>Yusuf Naufal Yafi' - 32241017</div>

        <div>Muhammad Rifai Al Faidzi - 32241003</div>

    </td>
</tr>

        <tr>

            <td><strong>Framework</strong></td>

            <td>: CodeIgniter 3</td>

        </tr>

        <tr>

            <td><strong>Template</strong></td>

            <td>: SB Admin 2</td>

        </tr>

        <tr>

            <td><strong>Database</strong></td>

            <td>: MySQL</td>

        </tr>

        <tr>

            <td><strong>Bahasa</strong></td>

            <td>: PHP 8 + JavaScript</td>

        </tr>

        <tr>

            <td><strong>Tahun</strong></td>

            <td>: <?= date('Y'); ?></td>

        </tr>

        <tr>

            <td><strong>Status Sistem</strong></td>

            <td>

                <span class="badge badge-success">

                    Aktif

                </span>

            </td>

        </tr>

    </table>

    <hr>

    <p class="mb-0 text-center text-muted">

        Dibuat sebagai proyek UAS
        Pemrograman Web II.

    </p>

</div>

                        </div>
                    </div>

                </div>

                <script>
    const dataPeminjaman = <?= json_encode($chart_peminjaman); ?>;

    const dataStatusBuku = <?= json_encode($status_buku); ?>;
</script>
                <!-- /.container-fluid -->
