<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800">Data E-Book</h1>

    <?= $this->session->flashdata('message'); ?>

    <div class="card">
        <div class="card-body">

<div class="row mb-3">

    <!-- Tombol Tambah -->
    <div class="col-md-6">

            <?php if (in_array(
               $this->session->userdata('nama'),
               ['Administrator', 'Petugas Perpus']
             )) : ?>
            <a href="<?= base_url('ebook/tambah'); ?>"
               class="btn btn-primary mb-3">
               Tambah E-Book
            </a>
           <?php endif; ?>

    </div>

           <!-- Form Search -->
    <div class="col-md-6">

        <form method="post"
              action="<?= base_url('ebook'); ?>">

            <div class="input-group">

                <input
                    type="text"
                    name="keyword"
                    class="form-control"
                    placeholder="Cari ebook..."
                    value="<?= $keyword; ?>">

                <div class="input-group-append">

                    <button
                        class="btn btn-primary"
                        type="submit">

                        <i class="fas fa-search"></i>
                        Search

                    </button>

                    <a href="<?= base_url('ebook/reset'); ?>"
                         class="btn btn-secondary">
                         <i class="fas fa-sync"></i>
                             Reset
                      </a>

                </div>

            </div>

        </form>

    </div>

</div>


            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Judul Buku</th>
                            <th>File/Link E-Book</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($ebook)) : ?>
                            <tr>
                                <td colspan="4" class="text-center">
                                    Belum ada data e-book.
                                </td>
                            </tr>
                        <?php else : ?>
                            <?php $no = $start + 1; ?>
                            <?php foreach ($ebook as $e) : ?>
                                <tr>
                                    <td><?= $no++; ?></td>
                                    <td><?= $e->judul; ?></td>
                                    <td><?= $e->file_pdf; ?></td>


<td>
    <?php if (in_array(
               $this->session->userdata('nama'),
               ['Administrator', 'Petugas Perpus']
             )) : ?>

    <a href="<?= base_url('ebook/edit/'.$e->id_ebook); ?>"
       class="btn btn-warning btn-sm">

        <i class="fas fa-edit"></i>

    </a>

    <a href="<?= base_url('ebook/hapus/'.$e->id_ebook); ?>"
       class="btn btn-danger btn-sm"
       onclick="return confirm('Yakin ingin menghapus data ini?')">

        <i class="fas fa-trash"></i>

    </a>

    <?php endif; ?>

</td>



                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>

                <?= $pagination; ?>
            </div>
        </div>
    </div>
</div>