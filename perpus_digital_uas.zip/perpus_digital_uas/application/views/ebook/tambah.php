<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800">Tambah E-Book</h1>

    <form method="post">
        <div class="form-group">
            <label>Buku</label>
            <select name="id_buku" class="form-control">
                <option value="">-- Pilih Buku --</option>
                <?php foreach ($buku as $b): ?>
                    <option value="<?= $b->id_buku; ?>"
                        <?= set_select('id_buku', $b->id_buku); ?>>
                        <?= $b->judul; ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <?= form_error('id_buku', '<small class="text-danger">', '</small>'); ?>
        </div>

        <div class="form-group">
            <label>File PDF</label>
            <input type="text" name="file_pdf" class="form-control"
                   value="<?= set_value('file_pdf'); ?>">
            <?= form_error('file_pdf', '<small class="text-danger">', '</small>'); ?>
        </div>

        <button type="submit" class="btn btn-primary">Simpan</button>
        <a href="<?= base_url('ebook'); ?>" class="btn btn-secondary">Kembali</a>
    </form>
</div>