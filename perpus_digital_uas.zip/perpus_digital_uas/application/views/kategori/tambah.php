<div class="container-fluid">

    <h1 class="h3 mb-4 text-gray-800">

        Tambah Kategori

    </h1>

    <div class="card shadow mb-4">

        <div class="card-body">

            <form method="post"
                 action="<?= base_url('kategori/tambah'); ?>">

                <div class="form-group">

    <label>Nama Kategori</label>

    <input
        type="text"
        name="nama_kategori"
        class="form-control"
        value="<?= set_value('nama_kategori'); ?>"
        placeholder="Masukkan Nama Kategori">

    <?= form_error(
        'nama_kategori',
        '<small class="text-danger">',
        '</small>'
    ); ?>

</div>

                <button
                    class="btn btn-primary">

                    Simpan

                </button>

                <a href="<?= base_url('kategori'); ?>"
                   class="btn btn-secondary">

                    Kembali

                </a>

            </form>

        </div>

    </div>

</div>