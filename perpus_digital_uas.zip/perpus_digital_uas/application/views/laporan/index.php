<!-- Begin Page Content -->
<div class="container-fluid">

    <h1 class="h3 mb-4 text-gray-800">

        Laporan Peminjaman

    </h1>

    <!-- Card Filter -->

    <div class="card shadow mb-4">

        <div class="card-header py-3">

            <h6 class="m-0 font-weight-bold text-primary">

                Filter Laporan

            </h6>

        </div>

        <div class="card-body">

            <form method="post">

                <?php

if (
    ($_SERVER['REQUEST_METHOD'] == 'POST') &&
    (
        empty($tanggal_awal) ||
        empty($tanggal_akhir)
    )
)
{

?>

<div class="alert alert-warning">

    Silakan isi tanggal awal dan tanggal akhir.

</div>

<?php

}

?>

                <div class="row">

                    <div class="col-md-4">

                        <label>Tanggal Awal</label>

                        <input
                            type="date"
                            name="tanggal_awal"
                            class="form-control"
                            value="<?= $tanggal_awal; ?>">

                    </div>

                    <div class="col-md-4">

                        <label>Tanggal Akhir</label>

                        <input
                            type="date"
                            name="tanggal_akhir"
                            class="form-control"
                            value="<?= $tanggal_akhir; ?>">

                    </div>

                    <div class="col-md-4">

                        <label>&nbsp;</label>

                        <br>

                        <button
    type="submit"
    class="btn btn-primary">

    <i class="fas fa-search"></i>

    Tampilkan

</button>

<a
    href="<?= base_url('laporan'); ?>"
    class="btn btn-secondary">

    Reset

</a>

<a
    href="<?= base_url('laporan/exportPdf?tanggal_awal=' . $tanggal_awal . '&tanggal_akhir=' . $tanggal_akhir); ?>"
    target="_blank"
    class="btn btn-danger">

    <i class="fas fa-file-pdf"></i>

    Export PDF

</a>
<br>

<a
    href="<?= base_url('laporan/exportExcel?tanggal_awal=' . $tanggal_awal . '&tanggal_akhir=' . $tanggal_akhir); ?>"
    class="btn btn-success">

    <i class="fas fa-file-excel"></i>

    Export Excel

</a>

<a
    href="<?= base_url('laporan/printLaporan?tanggal_awal=' . $tanggal_awal . '&tanggal_akhir=' . $tanggal_akhir); ?>"
    target="_blank"
    class="btn btn-info">

    <i class="fas fa-print"></i>

    Print

</a>

                    </div>

                </div>

            </form>

        </div>

    </div>

    <!-- Card Data -->

    <div class="card shadow">

        <div class="card-header py-3">

            <h6 class="m-0 font-weight-bold text-primary">

                Data Laporan

            </h6>

        </div>

        <div class="card-body">

            <div class="table-responsive">

                <table class="table table-bordered table-striped">

<thead>

<tr>

<th>No</th>

<th>Tanggal Pinjam</th>

<th>Nama Anggota</th>

<th>Judul Buku</th>

<th>Jumlah</th>

<th>Status</th>

<th>Denda</th>

</tr>

</thead>

<tbody>

<?php if (!empty($laporan)) : ?>

    <?php $no = 1; ?>

    <?php foreach ($laporan as $lp) : ?>

    <tr>

        <td><?= $no++; ?></td>

        <td>

            <?= date('d-m-Y', strtotime($lp->tanggal_pinjam)); ?>

        </td>

        <td>

            <?= $lp->nama_anggota; ?>

        </td>

        <td>

            <?= $lp->judul; ?>

        </td>

        <td class="text-center">

            <?= $lp->jumlah; ?>

        </td>

        <td>

            <?= $lp->status; ?>

        </td>

        <td class="text-right">

            Rp <?= number_format($lp->denda,0,',','.'); ?>

        </td>

    </tr>

    <?php endforeach; ?>

<?php else : ?>

<tr>

    <td colspan="7" class="text-center text-danger">

        <strong>Data laporan tidak ditemukan.</strong>

    </td>

</tr>

<?php endif; ?>

</tbody>

</table>

            </div>

        </div>

    </div>

</div>

<!-- /.container-fluid -->