<!DOCTYPE html>
<html>

<head>

<meta charset="utf-8">

<title>

Laporan Peminjaman

</title>

<style>

body{

    font-family: DejaVu Sans, sans-serif;

    font-size:12px;

}

h2{

    text-align:center;

    margin-bottom:5px;

}

p{

    text-align:center;

    margin-top:0;

}

table{

    width:100%;

    border-collapse:collapse;

}

table,
th,
td{

    border:1px solid black;

}

th{

    background:#eeeeee;

    text-align:center;

    padding:6px;

}

td{

    padding:6px;

}

.text-center{

    text-align:center;

}

.text-right{

    text-align:right;

}

</style>

</head>

<body>

<h2>

LAPORAN PEMINJAMAN

</h2>

<p>

Sistem Informasi Perpustakaan Digital

</p>

<table>

<thead>

<tr>

<th>No</th>

<th>Tanggal Pinjam</th>

<th>Nama Anggota</th>

<th>Judul Buku</th>

<th>Jumlah</th>

<th>Status</th>

<th>Denda</th>

</tr>

</thead>

<tbody>

<?php

$no=1;

foreach($laporan as $lp):

?>

<tr>

<td class="text-center">

<?= $no++; ?>

</td>

<td>

<?= date('d-m-Y',strtotime($lp->tanggal_pinjam)); ?>

</td>

<td>

<?= $lp->nama_anggota; ?>

</td>

<td>

<?= $lp->judul; ?>

</td>

<td class="text-center">

<?= $lp->jumlah; ?>

</td>

<td class="text-center">

<?= $lp->status; ?>

</td>

<td class="text-right">

Rp <?= number_format($lp->denda,0,',','.'); ?>

</td>

</tr>

<?php endforeach; ?>

</tbody>

</table>

</body>

</html>