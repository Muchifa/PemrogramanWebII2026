<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="utf-8">

    <title>

        Cetak Laporan

    </title>

    <link
        rel="stylesheet"
        href="<?= base_url('assets/vendor/bootstrap/css/bootstrap.min.css'); ?>">

<style>

@page{

    size:A4 portrait;

    margin:20mm;

}

body{

    font-family:Arial, Helvetica, sans-serif;

    font-size:12px;

    color:#000;

}

h3{

    text-align:center;

    font-weight:bold;

    margin-bottom:20px;

}

table{

    width:100%;

    border-collapse:collapse;

}

table th{

    text-align:center;

    background:#e9ecef;

}

table th,
table td{

    border:1px solid #000;

    padding:8px;

}

.table td{

    vertical-align:middle;

}

</style>

</head>

<body>

<div class="container">

    <div class="text-center">

        <h4 style="margin-bottom:0;">

            PERPUSTAKAAN DIGITAL

        </h4>

        <h5 style="margin-top:5px;">

            Sistem Informasi Perpustakaan

        </h5>

        <p>

            Jl. Contoh No. 123

        </p>

    </div>

    <hr style="border:2px solid black;">

    <h3 class="text-center">

        LAPORAN PEMINJAMAN

    </h3>

    <p>

        <strong>Periode :</strong>

        <?php

        if (!empty($tanggal_awal) && !empty($tanggal_akhir))
        {

            echo date(
                'd-m-Y',
                strtotime($tanggal_awal)
            );

            echo " s/d ";

            echo date(
                'd-m-Y',
                strtotime($tanggal_akhir)
            );

        }
        else
        {

            echo "Semua Data";

        }

        ?>

    </p>

    <hr style="border:1px solid black;">

    <table class="table table-bordered table-striped">

        <thead>

        <tr>

            <th>No</th>

            <th>Tanggal Pinjam</th>

            <th>Nama Anggota</th>

            <th>Judul Buku</th>

            <th>Jumlah</th>

            <th>Status</th>

            <th>Denda</th>

        </tr>

        </thead>

        <tbody>

        <?php

        $no = 1;

        foreach ($laporan as $lp) :

        ?>

        <tr>

            <td><?= $no++; ?></td>

            <td>

                <?= date('d-m-Y', strtotime($lp->tanggal_pinjam)); ?>

            </td>

            <td>

                <?= $lp->nama_anggota; ?>

            </td>

            <td>

                <?= $lp->judul; ?>

            </td>

            <td>

                <?= $lp->jumlah; ?>

            </td>

            <td>

                <?= $lp->status; ?>

            </td>

            <td>

                Rp <?= number_format($lp->denda,0,',','.'); ?>

            </td>

        </tr>

        <?php endforeach; ?>

        </tbody>

    </table>

    <br><br>

<div class="row">

    <div class="col-7">

    </div>

    <div class="col-5 text-center">

        <p>

            Purworejo,
            <!--?= date('d F Y'); ?-->
            <?= date('d F Y'); ?>

        </p>

        <p>

            Mengetahui,

        </p>

        <p>

            Petugas Perpustakaan

        </p>

        <br><br><br>

        <p>

            (................................)

        </p>

    </div>

</div>

</div>

<script>

window.onload = function()
{

    window.print();

};

window.onafterprint = function()
{

    window.close();

};

</script>

</body>

</html>