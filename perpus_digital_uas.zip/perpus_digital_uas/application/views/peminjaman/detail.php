<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

    <?= $this->session->flashdata('message'); ?>

    <div class="alert alert-info">
        Detail peminjaman #<?= $pinjam->id_pinjam; ?>
    </div>


    <form method="post">
    <div class="form-row mb-3">
        <div class="col-md-6">
            <select name="id_buku" class="form-control">
                <option value="">-- Pilih Buku --</option>
                <?php foreach ($buku as $b): ?>
                    <option value="<?= $b->id_buku; ?>">
                        <?= $b->judul; ?> (stok: <?= $b->stok; ?>)
                    </option>
                <?php endforeach; ?>
            </select>
            <?= form_error('id_buku', '<small class="text-danger">', '</small>'); ?>
        </div>
        <div class="col-md-3">
            <input type="number" name="jumlah" min="1"
                   class="form-control" placeholder="Jumlah">
            <?= form_error('jumlah', '<small class="text-danger">', '</small>'); ?>
        </div>
        <div class="col-md-3">
            <button type="submit" class="btn btn-primary btn-block">
                Tambah Buku
            </button>
        </div>
    </div>
</form>

    <div class="table-responsive">
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>No</th>
                <th>Judul Buku</th>
                <th>Jumlah</th>
                <th>Tanggal Kembali</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($detail)): ?>
                <tr>
                    <td colspan="5" class="text-center">
                        Belum ada buku pada transaksi ini.
                    </td>
                </tr>
            <?php else: ?>
                <?php $no = 1; foreach ($detail as $d): ?>
                    <tr>
                        <td><?= $no++; ?></td>
                        <td><?= $d->judul; ?></td>
                        <td><?= $d->jumlah; ?></td>
                        <td><?= $d->tanggal_kembali ?: '-'; ?></td>
                        <td>

                    <a href="<?= base_url('peminjaman/hapusDetail/'.$d->id_detail); ?>"
                       class="btn btn-danger btn-sm"
                       onclick="return confirm('Yakin ingin menghapus buku ini dari peminjaman?')">
                       Hapus
                    </a>

                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

    <a href="<?= base_url('peminjaman'); ?>"
                   class="btn btn-secondary">
                    Kembali
                </a>
</div>