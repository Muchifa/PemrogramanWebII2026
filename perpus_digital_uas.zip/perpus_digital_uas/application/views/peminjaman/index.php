<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

    <?= $this->session->flashdata('message'); ?>

    <div class="card">
        <div class="card-body">

            <!-- Tombol Tambah + Search -->

<div class="row mb-3">

    <!-- Tombol Tambah -->
    <div class="col-md-6">

        <?php if (in_array(
               $this->session->userdata('nama'),
               ['Administrator', 'Petugas Perpus']
             )) : ?>

        <a href="<?= base_url('peminjaman/tambah'); ?>"
           class="btn btn-primary">

            <i class="fas fa-plus"></i>
            Tambah Peminjaman

        </a>
        <?php endif; ?>

    </div>

    <!-- Form Search -->
    <div class="col-md-6">

        <form method="post"
              action="<?= base_url('peminjaman'); ?>">

            <div class="input-group">

                <input
                    type="text"
                    name="keyword"
                    class="form-control"
                    placeholder="Cari peminjaman..."
                    value="<?= $keyword; ?>">

                <div class="input-group-append">

                    <button
                        class="btn btn-primary"
                        type="submit">

                        <i class="fas fa-search"></i>
                        Search

                    </button>

                    <a href="<?= base_url('peminjaman/reset'); ?>"
                         class="btn btn-secondary">
                         <i class="fas fa-sync"></i>
                             Reset
                      </a>

                </div>

            </div>

        </form>

    </div>

</div>


            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Anggota</th>
                            <th>Petugas</th>
                            <th>Tanggal Pinjam</th>
                            <th>Jatuh Tempo</th>
                            <th>Status</th>

                            <?php if (in_array(
               $this->session->userdata('nama'),
               ['Administrator', 'Petugas Perpus']
             )) : ?>
                            <th>Aksi</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($peminjaman)) : ?>
                            <tr>
                                <td colspan="7" class="text-center">
                                    Belum ada data peminjaman.
                                </td>
                            </tr>
                        <?php else : ?>
                            <?php $no = $start + 1; ?>
                            <?php foreach ($peminjaman as $pm) : ?>
                                <tr>
                                    <td><?= $no++; ?></td>
                                    <td><?= $pm->nama_anggota; ?></td>
                                    <td><?= $pm->nama; ?></td>
                                    <td><?= $pm->tanggal_pinjam; ?></td>
                                    <td><?= $pm->tanggal_jatuh_tempo; ?></td>
                                    <td><?= $pm->status; ?></td>

<?php if (in_array(
               $this->session->userdata('nama'),
               ['Administrator', 'Petugas Perpus']
             )) : ?>
<td>
    

    <!--a href="<?= base_url('ebook/edit/'.$e->id_ebook); ?>"
       class="btn btn-warning btn-sm">

        <i class="fas fa-edit"></i>

    </a-->

    <a href="<?= base_url('peminjaman/hapus/'.$pm->id_pinjam); ?>"
       class="btn btn-danger btn-sm"
       onclick="return confirm('Yakin ingin menghapus transaksi ini?')">

        <i class="fas fa-trash"></i>

    </a>

    <a href="<?= base_url('peminjaman/detail/'.$pm->id_pinjam); ?>"
   class="btn btn-info btn-sm">
    Detail
</a>

</td>
<?php endif; ?>

                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>

                <?= $pagination; ?>
            </div>
        </div>
    </div>
</div>