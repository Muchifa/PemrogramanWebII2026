<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

    <div class="card">
        <div class="card-body">
            <form method="post">

                <div class="form-group">
                    <label>Anggota</label>
                    <select name="id_anggota" class="form-control">
                        <option value="">-- Pilih Anggota --</option>
                        <?php foreach ($anggota as $a): ?>
                            <option value="<?= $a->id_anggota; ?>">
                                <?= $a->nama_anggota; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <?= form_error('id_anggota', '<small class="text-danger">', '</small>'); ?>
                </div>

                <div class="form-group">
                    <label>Tanggal Pinjam</label>
                    <input type="date"
                           name="tanggal_pinjam"
                           class="form-control">
                    <?= form_error('tanggal_pinjam', '<small class="text-danger">', '</small>'); ?>
                </div>

                <div class="form-group">
                    <label>Tanggal Jatuh Tempo</label>
                    <input type="date"
                           name="tanggal_jatuh_tempo"
                           class="form-control">
                    <?= form_error('tanggal_jatuh_tempo', '<small class="text-danger">', '</small>'); ?>
                </div>

                <button type="submit" class="btn btn-primary">
                    Simpan
                </button>
                <a href="<?= base_url('peminjaman'); ?>"
                   class="btn btn-secondary">
                    Kembali
                </a>
            </form>
        </div>
    </div>
</div>