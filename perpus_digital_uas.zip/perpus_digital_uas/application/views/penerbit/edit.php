<div class="container-fluid">

    <h1 class="h3 mb-4 text-gray-800">

        Edit Penerbit

    </h1>

    <div class="card shadow mb-4">

        <div class="card-body">

            <form method="post"
      action="<?= base_url('penerbit/edit/'.$penerbit->id_penerbit); ?>">

                <div class="form-group">

    <label>Nama Penerbit</label>

    <input type="text"name="nama_penerbit"class="form-control"
        value="<?= set_value('nama_penerbit', $penerbit->nama_penerbit); ?>"
        placeholder="Masukkan Nama Penerbit">

    <?= form_error('nama_penerbit','<small class="text-danger">','</small>'); ?>

               </div>

               <div class="form-group">

    <label>Alamat Penerbit</label>

    <input type="text"name="alamat"class="form-control"
        value="<?= set_value('alamat', $penerbit->alamat); ?>"
        placeholder="Masukkan Alamat Penerbit">

    <?= form_error('alamat','<small class="text-danger">','</small>'); ?>

               </div>

               <div class="form-group">

    <label>No Telp Penerbit</label>

    <input type="text"name="telepom"class="form-control"
        value="<?= set_value('telepon', $penerbit->telepon); ?>"
        placeholder="Masukkan No Telp penerbit">

    <?= form_error('telepon','<small class="text-danger">','</small>'); ?>

               </div>

                <button class="btn btn-primary">

                    Simpan

                </button>

                <a href="<?= base_url('penerbit'); ?>"
                   class="btn btn-secondary">

                    Kembali

                </a>

            </form>

        </div>

    </div>

</div>