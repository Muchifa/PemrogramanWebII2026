<div class="container-fluid">

    <h1 class="h3 mb-4 text-gray-800">

        Tambah Penerbit

    </h1>

    <div class="card shadow mb-4">

        <div class="card-header py-3">

            <h6 class="m-0 font-weight-bold text-primary">

                Form Tambah Penerbit

            </h6>

        </div>

        <div class="card-body">

            <form method="post">

                <div class="form-group">

                    <label>Nama Penerbit</label>

            <input type="text"name="nama_penerbit"class="form-control"placeholder="Masukkan Nama Penerbit">
              <?= form_error('nama_penerbit','<small class="text-danger">','</small>'); ?>

                </div>

                <div class="form-group">

                    <label>Alamat Penerbit</label>

            <input type="text"name="alamat"class="form-control"placeholder="Masukkan Alamat Penerbit">
              <?= form_error('alamat','<small class="text-danger">','</small>'); ?>

                </div>

                <div class="form-group">

                    <label>No Telp Penerbit</label>

            <input type="text"name="telepon"class="form-control"placeholder="Masukkan No Telp Penerbit">
              <?= form_error('telepon','<small class="text-danger">','</small>'); ?>

                </div>

                <button type="submit"
                        class="btn btn-primary">

                    Simpan

                </button>

                <a href="<?= base_url('penerbit'); ?>"
                   class="btn btn-secondary">

                    Kembali

                </a>

            </form>

        </div>

    </div>

</div>