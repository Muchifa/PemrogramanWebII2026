<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

    <?= $this->session->flashdata('message'); ?>

    <div class="card">
        <div class="card-body">

<div class="row mb-3">
<!-- Form Search -->
    <div class="col-md-6">

        <form method="post"
              action="<?= base_url('pengembalian'); ?>">

            <div class="input-group">

                <input
                    type="text"
                    name="keyword"
                    class="form-control"
                    placeholder="Cari pengembalian..."
                    value="<?= $keyword; ?>">

                <div class="input-group-append">

                    <button
                        class="btn btn-primary"
                        type="submit">

                        <i class="fas fa-search"></i>
                        Search

                    </button>

                    <a href="<?= base_url('pengembalian/reset'); ?>"
                         class="btn btn-secondary">
                         <i class="fas fa-sync"></i>
                             Reset
                      </a>

                </div>

            </div>

        </form>

    </div>
</div>
            <div class="table-responsive">
            <table class="table table-bordered">
    <thead>
        <tr>
            <th>No</th>
            <th>Anggota</th>
            <th>Tgl Pinjam</th>
            <th>Jatuh Tempo</th>
            <th>Status</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php if (empty($pengembalian)): ?>
            <tr>
                <td colspan="6" class="text-center">
                    Belum ada data pengembalian.
                </td>
            </tr>
        <?php else: ?>
            <?php $no = $start + 1; foreach ($pengembalian as $p): ?>
                <tr>
                    <td><?= $no++; ?></td>
                    <td><?= $p->nama_anggota; ?></td>
                    <td><?= $p->tanggal_pinjam; ?></td>
                    <td><?= $p->tanggal_jatuh_tempo; ?></td>
                    <td><?= $p->status; ?></td>
                    <td>
                        <a href="<?= base_url('pengembalian/proses/'.$p->id_pinjam); ?>" 
                            class="btn btn-success btn-sm">
                            Proses
                        </a>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
    </tbody>
</table>

<?= $pagination; ?>
</div>
        </div>
    </div>
</div>