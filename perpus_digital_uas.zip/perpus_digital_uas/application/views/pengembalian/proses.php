<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

    <?= $this->session->flashdata('message'); ?>

    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Judul Buku</th>
                            <th>Jumlah</th>
                            <th>Denda</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($detail)): ?>
                            <tr>
                                <td colspan="5" class="text-center">
                                    Semua buku pada transaksi ini sudah dikembalikan.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php $no = 1; foreach ($detail as $d): ?>
                                <tr>
                                    <td><?= $no++; ?></td>
                                    <td><?= $d->judul; ?></td>
                                    <td><?= $d->jumlah; ?></td>
                                    <td>Rp <?= number_format($d->denda ?? 0, 0, ',', '.'); ?></td>
                                    <td>
                                        <a href="<?= base_url('pengembalian/kembalikan/'.$d->id_detail); ?>"
                                           class="btn btn-success btn-sm">
                                            Kembalikan
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <a href="<?= base_url('pengembalian'); ?>"
               class="btn btn-secondary">
                Kembali
            </a>
        </div>
    </div>
</div>