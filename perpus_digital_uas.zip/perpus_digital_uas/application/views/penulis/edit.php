<div class="container-fluid">

    <h1 class="h3 mb-4 text-gray-800">

        Edit Penulis

    </h1>

    <div class="card shadow mb-4">

        <div class="card-body">

            <form method="post"
      action="<?= base_url('penulis/edit/'.$penulis->id_penulis); ?>">

                <div class="form-group">

    <label>Nama Penulis</label>

    <input
        type="text"
        name="nama_penulis"
        class="form-control"
        value="<?= set_value('nama_penulis', $penulis->nama_penulis); ?>"
        placeholder="Masukkan Nama penulis">

    <?= form_error(
        'nama_penulis',
        '<small class="text-danger">',
        '</small>'
    ); ?>

</div>

                <button class="btn btn-primary">

                    Simpan

                </button>

                <a href="<?= base_url('penulis'); ?>"
                   class="btn btn-secondary">

                    Kembali

                </a>

            </form>

        </div>

    </div>

</div>