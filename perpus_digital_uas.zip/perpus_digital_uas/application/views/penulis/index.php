<div class="container-fluid">

    <h1 class="h3 mb-4 text-gray-800">

        Data Penulis

    </h1>

     <?= $this->session->flashdata('message'); ?>

    <div class="card shadow mb-4">

        <div class="card-header py-3">

            <h6 class="m-0 font-weight-bold text-primary">

                Master Data Penulis

            </h6>

        </div>

        <div class="card-body">

            <!-- Tombol Tambah + Search -->

<div class="row mb-3">

    <!-- Tombol Tambah -->
    <div class="col-md-6">

        <a href="<?= base_url('penulis/tambah'); ?>"
           class="btn btn-primary">

            <i class="fas fa-plus"></i>
            Tambah Penulis

        </a>

    </div>

    <!-- Form Search -->
    <div class="col-md-6">

        <form method="post"
              action="<?= base_url('penulis'); ?>">

            <div class="input-group">

                <input
                    type="text"
                    name="keyword"
                    class="form-control"
                    placeholder="Cari penulis..."
                    value="<?= $keyword; ?>">

                <div class="input-group-append">

                    <button
                        class="btn btn-primary"
                        type="submit">

                        <i class="fas fa-search"></i>
                        Search

                    </button>

                    <a href="<?= base_url('penulis/reset'); ?>"
                         class="btn btn-secondary">
                         <i class="fas fa-sync"></i>
                             Reset
                      </a>

                </div>

            </div>

        </form>

    </div>

</div>

            <table class="table table-bordered">

                <thead>

                    <tr>

                        <th width="70">No</th>
                        <th>Nama Penulis</th>
                        <th width="120">Aksi</th>

                    </tr>

                </thead>

                <tbody>

                <?php if (empty($penulis)) : ?>

                    <tr>

                        <td colspan="3" class="text-center text-muted">

                            Belum ada data penulis.

                        </td>

                    </tr>

                <?php else : ?>

                    <?php
                    $no = $start + 1;
                    foreach ($penulis as $p) :
                    ?>

                    <tr>

                        <td><?= $no++; ?></td>

                        <td><?= $p->nama_penulis; ?></td>

                        <td>

    <a href="<?= base_url('penulis/edit/'.$p->id_penulis); ?>"
       class="btn btn-warning btn-sm">

        <i class="fas fa-edit"></i>

    </a>

    <a href="<?= base_url('penulis/hapus/'.$p->id_penulis); ?>"
       class="btn btn-danger btn-sm"
       onclick="return confirm('Yakin ingin menghapus data ini?')">

        <i class="fas fa-trash"></i>

    </a>

</td>

                    </tr>

                    <?php endforeach; ?>

                <?php endif; ?>

                </tbody>

            </table>

            <?= $pagination; ?>

        </div>

    </div>

</div>