<div class="container-fluid">

    <h1 class="h3 mb-4 text-gray-800">

        Tambah Penulis

    </h1>

    <div class="card shadow mb-4">

        <div class="card-header py-3">

            <h6 class="m-0 font-weight-bold text-primary">

                Form Tambah Penulis

            </h6>

        </div>

        <div class="card-body">

            <form method="post">

                <div class="form-group">

                    <label>Nama Penulis</label>

                    <input type="text"
                           name="nama_penulis"
                           class="form-control"
                            placeholder="Masukkan Nama Penulis">

    <?= form_error(
        'nama_penulis',
        '<small class="text-danger">',
        '</small>'
    ); ?>

                </div>

                <button type="submit"
                        class="btn btn-primary">

                    Simpan

                </button>

                <a href="<?= base_url('penulis'); ?>"
                   class="btn btn-secondary">

                    Kembali

                </a>

            </form>

        </div>

    </div>

</div>