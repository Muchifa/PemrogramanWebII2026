<div class="container-fluid">

    <h1 class="h3 mb-4 text-gray-800">

        Edit Rak

    </h1>

    <div class="card shadow mb-4">

        <div class="card-body">

            <form method="post"
      action="<?= base_url('rak/edit/'.$rak->id_rak); ?>">

                <div class="form-group">

    <label>Nama Rak</label>

    <input type="text"name="nama_rak"class="form-control"
        value="<?= set_value('nama_rak', $rak->nama_rak); ?>"
        placeholder="Masukkan Nama Rak">

    <?= form_error('nama_rak','<small class="text-danger">','</small>'); ?>

               </div>

               <div class="form-group">

    <label>Lokasi Rak</label>

    <input type="text"name="lokasi"class="form-control"
        value="<?= set_value('lokasi', $rak->lokasi); ?>"
        placeholder="Masukkan Lokasi Rak">

    <?= form_error('lokasi','<small class="text-danger">','</small>'); ?>

               </div>


                <button class="btn btn-primary">

                    Simpan

                </button>

                <a href="<?= base_url('rak'); ?>"
                   class="btn btn-secondary">

                    Kembali

                </a>

            </form>

        </div>

    </div>

</div>