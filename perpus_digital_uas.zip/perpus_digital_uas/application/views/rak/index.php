<div class="container-fluid">
    
    <h1 class="h3 mb-4 text-gray-800">
        Data Rak
    </h1>

     <?= $this->session->flashdata('message'); ?>

    <div class="card shadow mb-4">

        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">
                Master Data Rak
            </h6>
        </div>

        <div class="card-body">

            <!-- Tombol Tambah + Search -->

<div class="row mb-3">

    <!-- Tombol Tambah -->
    <div class="col-md-6">

        <a href="<?= base_url('rak/tambah'); ?>"
           class="btn btn-primary">

            <i class="fas fa-plus"></i>
            Tambah Rak

        </a>

    </div>

    <!-- Form Search -->
    <div class="col-md-6">

        <form method="post"
              action="<?= base_url('rak'); ?>">

            <div class="input-group">

                <input
                    type="text"
                    name="keyword"
                    class="form-control"
                    placeholder="Cari rak..."
                    value="<?= $keyword; ?>">

                <div class="input-group-append">

                    <button
                        class="btn btn-primary"
                        type="submit">

                        <i class="fas fa-search"></i>
                        Search

                    </button>

                    <a href="<?= base_url('rak/reset'); ?>"
                         class="btn btn-secondary">
                         <i class="fas fa-sync"></i>
                             Reset
                      </a>

                </div>

            </div>

        </form>

    </div>

</div>

            <table class="table table-bordered">

                <thead>

                    <tr>

                        <th width="70">No</th>
                        <th>Nama Rak</th>
                        <th>Lokasi Rak</th>
                        <th>Aksi</th>

                    </tr>

                </thead>

                <tbody>

                <?php if (empty($rak)) : ?>

                    <tr>

                        <td colspan="5" class="text-center text-muted">

                            Belum ada data rak.

                        </td>

                    </tr>

                <?php else : ?>

                    <?php
                    $no = $start + 1;
                    foreach ($rak as $rk) :
                    ?>

                    <tr>

                        <td><?= $no++; ?></td>

                        <td><?= $rk->nama_rak; ?></td>
                        <td><?= $rk->lokasi; ?></td>

                        <td>

    <a href="<?= base_url('rak/edit/'.$rk->id_rak); ?>"
       class="btn btn-warning btn-sm">

        <i class="fas fa-edit"></i>

    </a>

    <a href="<?= base_url('rak/hapus/'.$rk->id_rak); ?>"
       class="btn btn-danger btn-sm"
       onclick="return confirm('Yakin ingin menghapus data ini?')">

        <i class="fas fa-trash"></i>

    </a>

</td>

                    </tr>

                    <?php endforeach; ?>

                <?php endif; ?>

                </tbody>

            </table>

            <?= $pagination; ?>

        </div>

    </div>

</div>