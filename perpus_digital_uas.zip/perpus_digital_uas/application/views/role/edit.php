<div class="container-fluid">

    <h1 class="h3 mb-4 text-gray-800">
        Edit Role
    </h1>

    <div class="card shadow">

        <div class="card-header">
            Form Edit Role
        </div>

        <div class="card-body">
            <!--?= base_url('role/update'); ?-->

            <form action=""
                  method="post">

                <input type="hidden"
                       name="id_role"
                       value="<?= $role->id_role; ?>">

                <div class="form-group">

                    <label>
                        Nama Role
                    </label>

                    <input type="text"
                           name="nama_role"
                           class="form-control"
                           value="<?= $role->nama_role; ?>">

                           <?= form_error('nama_role', '<small class="text-danger">','</small>'); ?>

                </div>

                <button type="submit"
                        class="btn btn-primary">
                    Simpan
                </button>

                <a href="<?= base_url('role'); ?>"
                   class="btn btn-secondary">
                    Kembali
                </a>

            </form>

        </div>

    </div>

</div>