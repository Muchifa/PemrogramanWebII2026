<div class="container-fluid">

    <h1 class="h3 mb-4 text-gray-800">
        Data Role
    </h1>

    <div class="card shadow">

        <div class="card-header">
            Data Role
        </div>

        <div class="card-body">

            <?= $this->session->flashdata('message'); ?>

           <div class="row mb-3">

    <!-- Tombol Tambah -->
    <div class="col-md-6">

        <a href="<?= base_url('role/tambah'); ?>"
           class="btn btn-primary">

            <i class="fas fa-plus"></i>
            Tambah Role

        </a>

    </div>

    <!-- Form Search -->
    <div class="col-md-6">

        <form method="post">

            <div class="input-group">

                <input type="text"
                       name="keyword"
                       class="form-control"
                       placeholder="Cari role..."
                       value="<?= isset($keyword) ? $keyword : ''; ?>">

                <div class="input-group-append">

                    <button class="btn btn-primary"
                            type="submit">

                        Cari

                    </button>

                <?php if(!empty($keyword)) : ?>

                    <a href="<?= base_url('role/reset'); ?>" 
                        class="btn btn-secondary">

                        Reset

                    </a>

                <?php endif; ?>

                </div>

            </div>

        </form>

    </div>

</div>

            <table class="table table-bordered">

                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Role</th>
                        <th>Aksi</th>
                    </tr>
                </thead>

                <tbody>

<?php if(empty($role)): ?>

<tr>
    <td colspan="3" class="text-center">

        <?php if($total_role == 0)
        {
            echo 'Tidak ada data role';
        }
        else
        {
            echo 'Data role tidak ditemukan';
        }
        ?>
    </td>
</tr>

<?php else: ?>

<?php
$no = 1;
foreach($role as $r):
?>

<tr>
    <td><?= $no++; ?></td>

    <td><?= $r->nama_role; ?></td>

    <td>
        <a href="<?= base_url('role/edit/'.$r->id_role); ?>"
           class="btn btn-warning btn-sm">
            Edit
        </a>

        <a href="<?= base_url('role/delete/'.$r->id_role); ?>"
   class="btn btn-danger btn-sm"
   onclick="return confirm('Apakah yakin ingin menghapus role ini?')">

    Hapus

</a>
    </td>
</tr>

<?php endforeach; ?>

<?php endif; ?>

</tbody>

            </table>

            <?= $pagination ?>

        </div>

    </div>

</div>