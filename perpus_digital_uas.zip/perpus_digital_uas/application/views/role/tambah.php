<div class="container-fluid">

    <h1 class="h3 mb-4 text-gray-800">
        Tambah Role
    </h1>

    <div class="card shadow">

        <div class="card-header">
            Form Tambah Role
        </div>

        <div class="card-body">

            <form method="post">

                <div class="form-group">

                    <label>Nama Role</label>

                    <input type="text"
                           name="nama_role"
                           class="form-control">

                           <?= form_error('nama_role', '<small class="text-danger">','</small>'); ?>

                </div>

                <button type="submit"
                        class="btn btn-primary">

                    Simpan

                </button>

                <a href="<?= base_url('role'); ?>"
                   class="btn btn-secondary">

                    Kembali

                </a>

            </form>

        </div>

    </div>

</div>