</div>
            <!-- End of Main Content -->

<!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Perpustakaan Digital UAS</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->
        </div>
            <!-- End of Content Wrapper -->
        </div>
            <!-- End of Page Wrapper -->