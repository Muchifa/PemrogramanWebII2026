<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<!-- Logout Modal-->
<div class="modal fade"
     id="logoutModal"
     tabindex="-1"
     role="dialog"
     aria-labelledby="logoutModalLabel"
     aria-hidden="true">

    <div class="modal-dialog"
         role="document">

        <div class="modal-content">

            <div class="modal-header">

                <h5 class="modal-title"
                    id="logoutModalLabel">

                    Logout

                </h5>

                <button class="close"
                        type="button"
                        data-dismiss="modal"
                        aria-label="Close">

                    <span aria-hidden="true">&times;</span>

                </button>

            </div>

            <div class="modal-body">

                Anda yakin ingin keluar dari sistem?

            </div>

            <div class="modal-footer">

                <button class="btn btn-secondary"
                        type="button"
                        data-dismiss="modal">

                    Batal

                </button>

                <a class="btn btn-primary"
                   href="<?= base_url('auth/logout'); ?>">

                    Logout

                </a>

            </div>

        </div>

    </div>

</div>

<!-- Bootstrap core JavaScript-->
<script src="<?= base_url('assets/vendor/jquery/jquery.min.js'); ?>"></script>

<script src="<?= base_url('assets/vendor/bootstrap/js/bootstrap.bundle.min.js'); ?>"></script>

<!-- Core plugin JavaScript-->
<script src="<?= base_url('assets/vendor/jquery-easing/jquery.easing.min.js'); ?>"></script>

<!-- Custom scripts for all pages-->
<script src="<?= base_url('assets/js/sb-admin-2.min.js'); ?>"></script>

<!-- Page level plugins -->
<script src="<?= base_url('assets/vendor/chart.js/Chart.min.js'); ?>"></script>

<script>
    const dataPeminjaman = <?= json_encode($chart_peminjaman); ?>;

    const dataStatusBuku = <?= json_encode($status_buku); ?>;
</script>

<!-- Page level custom scripts -->

<script src="<?= base_url('assets/js/dashboard-chart.js'); ?>"></script>

<script src="<?= base_url('assets/js/dashboard-pie.js'); ?>"></script>

<!--script src="<?= base_url('assets/js/demo/chart-area-demo.js'); ?>"></script-->

<!--script src="<?= base_url('assets/js/demo/chart-pie-demo.js'); ?>"></script-->

</body>

</html>