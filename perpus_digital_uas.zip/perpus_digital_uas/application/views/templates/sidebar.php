<!-- Sidebar -->
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center"
       href="<?= base_url('dashboard'); ?>">

        <div class="sidebar-brand-icon rotate-n-15">
            <i class="fas fa-book"></i>
        </div>

        <div class="sidebar-brand-text mx-3">
            Perpus Digital
        </div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item active">
        <a class="nav-link"
           href="<?= base_url('dashboard'); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span>
        </a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    <div class="sidebar-heading">
        Master Data
    </div>

    <!-- Nav Item - User -->

    <?php if($this->session->userdata('id_role') == ROLE_ADMIN ):?>

    <li class="nav-item">
        <a class="nav-link"
           href="<?= base_url('user'); ?>">
            <i class="fas fa-fw fa-users"></i>
            <span>Data User</span>
        </a>
    </li>

    <?php endif; ?>

    <!-- Nav Item - Role -->

    <?php if($this->session->userdata('id_role') == ROLE_ADMIN ):?>

    <li class="nav-item">
        <a class="nav-link"
           href="<?= base_url('role'); ?>">
            <i class="fas fa-fw fa-user-tag"></i>
            <span>Role</span>
        </a>
    </li>

    <?php endif; ?>

    <!-- Nav Item - Kategori -->

    <?php
         if(
             $this->session->userdata('id_role') == ROLE_ADMIN || 
             $this->session->userdata('id_role') == ROLE_PETUGAS
           ):
       ?>

    <li class="nav-item">
        <a class="nav-link"
           href="<?= base_url('kategori'); ?>">
            <i class="fas fa-fw fa-tags"></i>
            <span>Kategori</span>
        </a>
    </li>

    <?php endif; ?>

    <!-- Nav Item - Penulis -->

    <?php
         if(
             $this->session->userdata('id_role') == ROLE_ADMIN || 
             $this->session->userdata('id_role') == ROLE_PETUGAS
           ):
       ?>

    <li class="nav-item">
        <a class="nav-link"
           href="<?= base_url('penulis'); ?>">
            <i class="fas fa-fw fa-pen"></i>
            <span>Penulis</span>
        </a>
    </li>

    <?php endif; ?>

    <!-- Nav Item - Penerbit -->

    <?php
         if(
             $this->session->userdata('id_role') == ROLE_ADMIN || 
             $this->session->userdata('id_role') == ROLE_PETUGAS
           ):
       ?>

    <li class="nav-item">
        <a class="nav-link"
           href="<?= base_url('penerbit'); ?>">
            <i class="fas fa-fw fa-building"></i>
            <span>Penerbit</span>
        </a>
    </li>

    <?php endif; ?>

    <!-- Nav Item - Rak -->

    <?php
         if(
             $this->session->userdata('id_role') == ROLE_ADMIN || 
             $this->session->userdata('id_role') == ROLE_PETUGAS
           ):
       ?>

    <li class="nav-item">
        <a class="nav-link"
           href="<?= base_url('rak'); ?>">
            <i class="fas fa-fw fa-archive"></i>
            <span>Rak</span>
        </a>
    </li>

    <?php endif; ?>

    <!-- Nav Item - Buku -->

    <?php
         if(
             $this->session->userdata('id_role') == ROLE_ADMIN || 
             $this->session->userdata('id_role') == ROLE_PETUGAS
           ):
       ?>

    <li class="nav-item">
        <a class="nav-link"
           href="<?= base_url('buku'); ?>">
            <i class="fas fa-fw fa-book"></i>
            <span>Buku</span>
        </a>
    </li>

    <?php endif; ?>

    <!-- Nav Item - Ebook -->

    <li class="nav-item">
        <a class="nav-link"
           href="ebook">
            <i class="fas fa-fw fa-file-pdf"></i>
            <span>Ebook</span>
        </a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    <div class="sidebar-heading">
        Transaksi
    </div>

    <!-- Nav Item - Anggota -->

    <?php
         if(
             $this->session->userdata('id_role') == ROLE_ADMIN || 
             $this->session->userdata('id_role') == ROLE_PETUGAS
           ):
       ?>

    <li class="nav-item">
        <a class="nav-link"
           href="<?= base_url('anggota'); ?>">
            <i class="fas fa-fw fa-address-card"></i>
            <span>Anggota</span>
        </a>
    </li>

    <?php endif; ?>

    <!-- Nav Item - Peminjaman -->

    <?php
         if(
             $this->session->userdata('id_role') == ROLE_ADMIN || 
             $this->session->userdata('id_role') == ROLE_PETUGAS
           ):
       ?>

    <li class="nav-item">
        <a class="nav-link"
           href="<?= base_url('peminjaman'); ?>">
            <i class="fas fa-fw fa-exchange-alt"></i>
            <span>Peminjaman</span>
        </a>
    </li>

    <?php endif; ?>

    <!-- Nav Item - Pengembalian -->

    <?php
         if(
             $this->session->userdata('id_role') == ROLE_ADMIN || 
             $this->session->userdata('id_role') == ROLE_PETUGAS
           ):
       ?>

    <li class="nav-item">
        <a class="nav-link"
           href="<?= base_url('pengembalian'); ?>">
            <i class="fas fa-fw fa-undo"></i>
            <span>Pengembalian</span>
        </a>
    </li>

    <?php endif; ?>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    <div class="sidebar-heading">
        Laporan
    </div>

    <!-- Nav Item - Laporan -->

    <?php
         if(
             $this->session->userdata('id_role') == ROLE_ADMIN || 
             $this->session->userdata('id_role') == ROLE_PETUGAS
           ):
       ?>

    <li class="nav-item">
        <a class="nav-link"
           href="<?= base_url('laporan'); ?>">
            <i class="fas fa-fw fa-file-alt"></i>
            <span>Laporan</span>
        </a>
    </li>

    <?php endif; ?>

    <!-- Divider -->
    <hr class="sidebar-divider d-none d-md-block">

    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0"
                id="sidebarToggle"></button>
    </div>

</ul>
<!-- End of Sidebar -->

<!-- Content Wrapper -->
<div id="content-wrapper" class="d-flex flex-column">

    <!-- Main Content -->
    <div id="content">