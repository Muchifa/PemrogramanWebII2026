<div class="container-fluid">

<h1 class="h3 mb-4 text-gray-800">
    <?= $title; ?>
</h1>

<div class="card">

    <div class="card-header">
        Edit User
    </div>

    <div class="card-body">

        <form action="" method="post">

            <input type="hidden"
                   name="id_user"
                   value="<?= $user->id_user; ?>">

            <div class="form-group">
                <label>Nama</label>

                <input
type="text"
name="nama"
class="form-control"
value="<?= $user->nama; ?>">

<?= form_error('nama','<small class="text-danger">','</small>'); ?>
            </div>

            <div class="form-group">
                <label>Username</label>

                <input
type="text"
name="username"
class="form-control"
value="<?= $user->username; ?>">

<?= form_error('username','<small class="text-danger">','</small>'); ?>
            </div>

            <div class="form-group">
                <label>Password</label>

                <input
type="text"
name="password"
class="form-control"
value="<?= $user->password; ?>">

<?= form_error('password','<small class="text-danger">','</small>'); ?>
            </div>

            <div class="form-group">

                <label>Role</label>

                <select
                    name="id_role"
                    class="form-control">

                    <?= form_error('id_role','<small class="text-danger">','</small>'); ?>

                    <option value="">
                        -- Pilih Role --
                    </option>

                    <?php foreach($role as $r): ?>

<option
value="<?= $r->id_role; ?>"

<?= ($r->id_role == $user->id_role)
    ? 'selected'
    : ''; ?>>

<?= $r->nama_role; ?>

</option>

<?php endforeach; ?>

</select>

            </div>

            <button
                class="btn btn-primary">

                Update

            </button>

            <a
                href="<?= base_url('user'); ?>"
                class="btn btn-secondary">

                Kembali

            </a>

        </form>

    </div>

</div>

</div>