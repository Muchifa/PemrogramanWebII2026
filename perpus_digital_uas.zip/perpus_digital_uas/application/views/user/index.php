<div class="container-fluid">

    <h1 class="h3 mb-4 text-gray-800">

        Data User

    </h1>

    <div class="card shadow">

        <div class="card-header">

            Data User

        </div>

        <div class="card-body">

            <?= $this->session->flashdata('message'); ?>

            <div class="row mb-3">

                <!-- Tombol Tambah -->

                <div class="col-md-6">

                    <a href="<?= base_url('user/tambah'); ?>"
                       class="btn btn-primary">

                        <i class="fas fa-plus"></i>
                        Tambah User

                    </a>

                </div>

                <!-- Form Search -->

                <div class="col-md-6">

                    <form method="post">

                        <div class="input-group">

                            <input
                                type="text"
                                name="keyword"
                                class="form-control"
                                placeholder="Cari user..."
                                value="<?= isset($keyword) ? $keyword : ''; ?>">

                            <div class="input-group-append">

                                <button
                                    class="btn btn-primary"
                                    type="submit">

                                    Cari

                                </button>

                                <?php if(!empty($keyword)) : ?>

                                    <a href="<?= base_url('user/reset'); ?>"
                                       class="btn btn-secondary">

                                        Reset

                                    </a>

                                <?php endif; ?>

                            </div>

                        </div>

                    </form>

                </div>

            </div> <!-- END OF ROW -->

            <table class="table table-bordered">

                <thead>

                    <tr>

                        <th>No</th>

                        <th>Nama</th>

                        <th>Username</th>

                        <th>Role</th>

                        <th>Aksi</th>

                    </tr>

                </thead>

                <tbody>

<?php if(empty($user)): ?>

<tr>

    <td colspan="5" class="text-center">

        <?php if($this->User_model->jumlah() == 0): ?>

            Tidak ada Data User

        <?php else: ?>

            Data user tidak ditemukan

        <?php endif; ?>

    </td>

</tr>

<?php else: ?>

<?php
$no = $start + 1;
foreach($user as $u):
?>

<tr>

    <td><?= $no++; ?></td>

    <td><?= $u->nama; ?></td>

    <td><?= $u->username; ?></td>

    <td><?= $u->nama_role; ?></td>

    <td>

        <a href="<?= base_url('user/edit/'.$u->id_user); ?>"
           class="btn btn-warning btn-sm">

            Edit

        </a>

        <a href="<?= base_url('user/delete/'.$u->id_user); ?>"
           class="btn btn-danger btn-sm"
           onclick="return confirm('Apakah yakin ingin menghapus user ini?')">

            Hapus

        </a>

    </td>

</tr>

<?php endforeach; ?>

<?php endif; ?>

</tbody>

            </table>

            <?= $pagination; ?>

        </div>

    </div>

</div>