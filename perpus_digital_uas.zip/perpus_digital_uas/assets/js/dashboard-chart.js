// Default Font ChartJS
Chart.defaults.global.defaultFontFamily =
'Nunito,-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';

Chart.defaults.global.defaultFontColor = "#858796";

// ===========================
// GRAFIK PEMINJAMAN
// ===========================

var ctx = document.getElementById("myAreaChart");

if(ctx){

    new Chart(ctx,{

        type : "line",

        data : {

            labels : [
                "Jan",
                "Feb",
                "Mar",
                "Apr",
                "Mei",
                "Jun",
                "Jul",
                "Ags",
                "Sep",
                "Okt",
                "Nov",
                "Des"
            ],

            datasets : [

                {

                    label : "Jumlah Peminjaman",

                    data : dataPeminjaman,

                    backgroundColor :
                    "rgba(78,115,223,0.05)",

                    borderColor :
                    "rgba(78,115,223,1)",

                    borderWidth : 2,

                    pointRadius : 3,

                    pointBackgroundColor :
                    "rgba(78,115,223,1)",

                    pointBorderColor :
                    "rgba(78,115,223,1)",

                    pointHoverRadius : 5,

                    pointHoverBackgroundColor :
                    "rgba(78,115,223,1)",

                    pointHoverBorderColor :
                    "rgba(78,115,223,1)",

                    fill : true,

                    tension : 0.3

                }

            ]

        },

        options : {

            responsive : true,

            maintainAspectRatio : false,

            scales : {

                yAxes : [

                    {

                        ticks : {

                            beginAtZero : true,

                            precision : 0

                        }

                    }

                ]

            },

            legend : {

                display : true

            }

        }

    });

}