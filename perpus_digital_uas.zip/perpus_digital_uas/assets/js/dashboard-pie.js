// Donut Chart Status Buku

var ctx = document.getElementById("myPieChart");

if (ctx) {

    new Chart(ctx, {

        type: 'doughnut',

        data: {

            labels: [

                "Tersedia",

                "Dipinjam"

            ],

            datasets: [

                {

                    data: [

                        dataStatusBuku.tersedia,

                        dataStatusBuku.dipinjam

                    ],

                    backgroundColor: [

                        '#1cc88a',

                        '#e74a3b'

                    ],

                    hoverBackgroundColor: [

                        '#17a673',

                        '#c0392b'

                    ],

                    hoverBorderColor: "rgba(234,236,244,1)"

                }

            ]

        },

        options: {

            maintainAspectRatio: false,

            tooltips: {

                backgroundColor: "rgb(255,255,255)",

                bodyFontColor: "#858796",

                borderColor: '#dddfeb',

                borderWidth: 1,

                xPadding: 15,

                yPadding: 15,

                displayColors: false,

                caretPadding: 10

            },

            legend: {

                display: true,

                position: 'bottom'

            },

            cutoutPercentage: 65

        }

    });

}