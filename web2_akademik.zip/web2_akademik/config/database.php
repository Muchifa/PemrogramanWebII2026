<?php

$host = "localhost";
$user = "root";
$pass = "";
$db   = "web2_tugas";

$koneksi = mysqli_connect($host,$user,$pass,$db);

if(!$koneksi){
    die("Koneksi gagal : " . mysqli_connect_error());
}
?>