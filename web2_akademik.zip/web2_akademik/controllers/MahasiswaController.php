<?php
require_once "models/Mahasiswa.php";
require_once "models/Tugas.php";

class MahasiswaController{

    /* ================= ADMIN ================= */

    public function index(){
        $model = new Mahasiswa();
		
		// ambil data mahasiswa dari model
        $mahasiswa = $model->getAll();
        require "views/admin/mahasiswa.php";
    }

    public function tambah(){
        require "views/admin/mahasiswa_tambah.php";
    }

    public function simpan(){
        $model = new Mahasiswa();
        $model->insert($_POST['nim'], $_POST['nama'], $_POST['email']);

        header("Location:index.php?page=mahasiswa");
        exit;
    }

    public function edit($id){
        $model = new Mahasiswa();
        $row = $model->getById($id);

        require "views/admin/mahasiswa_edit.php";
    }

    public function update(){
        $model = new Mahasiswa();
        $model->update(
            $_POST['id'],
            $_POST['nim'],
            $_POST['nama'],
            $_POST['email']
        );

        header("Location:index.php?page=mahasiswa");
        exit;
    }

    public function hapus($id){
        $model = new Mahasiswa();
        $model->delete($id);

        header("Location:index.php?page=mahasiswa");
        exit;
    }


    /* ================= ROLE MAHASISWA ================= */

    public function dashboard(){
        require "views/mahasiswa/dashboard.php";
    }

    public function tugas(){
        $model = new Tugas();
        $tugas = $model->getAll();

        require "views/mahasiswa/tugas.php";
    }

}
?>