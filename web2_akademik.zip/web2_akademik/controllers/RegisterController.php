<?php
require_once "config/database.php";

class RegisterController{

    public function simpan(){

        global $koneksi;

        $username = $_POST['username'];
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $role     = 'mahasiswa';

        mysqli_query($koneksi,
        "INSERT INTO users(username,password,role)
         VALUES('$username','$password','$role')");

        header("Location:index.php?page=login");
        exit;
    }
}
?>