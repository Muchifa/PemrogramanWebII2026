<?php

require_once "models/Tugas.php";

class TugasController{

    public function index(){

        $model = new Tugas();
        $tugas = $model->getAll();

        require "views/admin/tugas.php";
    }


    public function tambah(){

        require "views/admin/tugas_tambah.php";
    }


    public function simpan(){

        $model = new Tugas();

        $judul     = $_POST['judul'];
        $deskripsi = $_POST['deskripsi'];
        $deadline  = $_POST['deadline'];

        $model->insert($judul, $deskripsi, $deadline);

        header("Location: index.php?page=tugas");
        exit;
    }


    /* ================= EDIT ================= */

    public function edit($id){

        $model = new Tugas();

        $data = $model->getById($id);

        require "views/admin/tugas_edit.php";
    }


    /* ================= UPDATE ================= */

    public function update(){

        $model = new Tugas();

        $id        = $_POST['id'];
        $judul     = $_POST['judul'];
        $deskripsi = $_POST['deskripsi'];
        $deadline  = $_POST['deadline'];

        $model->update($id, $judul, $deskripsi, $deadline);

        header("Location: index.php?page=tugas");
        exit;
    }


    /* ================= HAPUS ================= */

    public function hapus($id){

        $model = new Tugas();

        $model->delete($id);

        header("Location: index.php?page=tugas");
        exit;
    }

}
?>