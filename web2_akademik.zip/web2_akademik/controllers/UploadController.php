<?php

class UploadController{

    public function form($id){

        require "views/mahasiswa/upload.php";
    }

    public function simpan(){

        $namaFile = $_FILES['file']['name'];
        $tmp      = $_FILES['file']['tmp_name'];

        move_uploaded_file($tmp, "uploads/".$namaFile);

        header("Location:index.php?page=lihat_tugas");
        exit;
    }
}
?>