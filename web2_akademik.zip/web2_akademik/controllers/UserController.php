<?php

require_once "config/database.php";
require_once "models/User.php";

class UserController{

    private $user;

    public function __construct(){

        global $koneksi;
        $this->user = new User($koneksi);

    }

    /* ================= TAMPIL DATA ================= */

    public function index(){

        $data = $this->user->db();

        require "views/admin/user.php";
    }


    /* ================= FORM TAMBAH ================= */

    public function tambah(){

        require "views/admin/user_tambah.php";
    }


    /* ================= SIMPAN DATA ================= */

    public function simpan(){

        $username = $_POST['username'];
        $password = $_POST['password'];
        $role     = $_POST['role'];

        $this->user->insert($username, $password, $role);

        header("Location: index.php?page=user");
        exit;
    }


    /* ================= FORM EDIT ================= */

    public function edit($id){

        $data = $this->user->find($id);
        $row  = mysqli_fetch_assoc($data);

        require "views/admin/user_edit.php";
    }


    /* ================= UPDATE DATA ================= */

    public function update(){

        $id       = $_POST['id'];
        $username = $_POST['username'];
        $password = $_POST['password'];
        $role     = $_POST['role'];

        $this->user->update($id, $username, $password, $role);

        header("Location: index.php?page=user");
        exit;
    }


    /* ================= HAPUS DATA ================= */

    public function hapus($id){

        $this->user->delete($id);

        header("Location: index.php?page=user");
        exit;
    }

}
?>