<?php

echo password_hash("mhs123", PASSWORD_DEFAULT);

?>