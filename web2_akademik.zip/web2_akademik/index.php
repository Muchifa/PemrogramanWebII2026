<?php
session_start();

$page = $_GET['page'] ?? 'login';
$id   = $_GET['id'] ?? null;

switch ($page) {

    /* ================= LOGIN ================= */

    case 'login':
        require 'views/auth/login.php';
        break;

    case 'login-proses':
        require 'controllers/AuthController.php';
        $controller = new AuthController();
        $controller->login();
        break;



    /* ================= DASHBOARD ================= */

    case 'dashboard':

        if (!isset($_SESSION['login'])) {
            header("Location: index.php?page=login");
            exit;
        }

        if ($_SESSION['role'] == 'admin') {

            require 'controllers/AdminController.php';
            $controller = new AdminController();
            $controller->dashboard();

        } elseif ($_SESSION['role'] == 'mahasiswa') {

            require 'controllers/MahasiswaController.php';
            $controller = new MahasiswaController();
            $controller->dashboard();

        } else {

            echo "Role tidak dikenali";

        }

        break;



    /* ================= MAHASISWA ================= */

    case 'mahasiswa':
        require 'controllers/MahasiswaController.php';
        $controller = new MahasiswaController();
        $controller->index();
        break;

    case 'tambah_mahasiswa':
        require 'controllers/MahasiswaController.php';
        $controller = new MahasiswaController();
        $controller->tambah();
        break;

    case 'simpan_mahasiswa':
        require 'controllers/MahasiswaController.php';
        $controller = new MahasiswaController();
        $controller->simpan();
        break;

    case 'edit_mahasiswa':
        require 'controllers/MahasiswaController.php';
        $controller = new MahasiswaController();
        $controller->edit($id);
        break;

    case 'update_mahasiswa':
        require 'controllers/MahasiswaController.php';
        $controller = new MahasiswaController();
        $controller->update();
        break;

    case 'hapus_mahasiswa':
        require 'controllers/MahasiswaController.php';
        $controller = new MahasiswaController();
        $controller->hapus($id);
        break;



    /* ================= TUGAS ================= */

    case 'tugas':
        require 'controllers/TugasController.php';
        $controller = new TugasController();
        $controller->index();
        break;

    case 'tambah_tugas':
        require 'controllers/TugasController.php';
        $controller = new TugasController();
        $controller->tambah();
        break;

    case 'simpan_tugas':
        require 'controllers/TugasController.php';
        $controller = new TugasController();
        $controller->simpan();
        break;

    case 'edit_tugas':
        require 'controllers/TugasController.php';
        $controller = new TugasController();
        $controller->edit($id);
        break;

    case 'update_tugas':
        require 'controllers/TugasController.php';
        $controller = new TugasController();
        $controller->update();
        break;

    case 'hapus_tugas':
        require 'controllers/TugasController.php';
        $controller = new TugasController();
        $controller->hapus($id);
        break;



    /* ================= USER ================= */

    case 'user':
        require 'controllers/UserController.php';
        $controller = new UserController();
        $controller->index();
        break;

    case 'tambah_user':
        require 'controllers/UserController.php';
        $controller = new UserController();
        $controller->tambah();
        break;

    case 'simpan_user':
        require 'controllers/UserController.php';
        $controller = new UserController();
        $controller->simpan();
        break;
		

    case 'edit_user':
        require 'controllers/UserController.php';
        $controller = new UserController();
        $controller->edit($id);
        break;

    case 'update_user':
        require 'controllers/UserController.php';
        $controller = new UserController();
        $controller->update();
        break;

    case 'hapus_user':
        require 'controllers/UserController.php';
        $controller = new UserController();
        $controller->hapus($id);
        break;


    case 'register':
         require 'views/auth/register.php';
         break;

    case 'register-proses':
        require 'controllers/RegisterController.php';
        $controller = new RegisterController();
        $controller->simpan();
        break;


    /* ================= LOGOUT ================= */

    case 'logout':
        session_destroy();
        header("Location: index.php?page=login");
        break;



    /* ================= DEFAULT ================= */

    default:
        echo "Halaman tidak ditemukan";
}