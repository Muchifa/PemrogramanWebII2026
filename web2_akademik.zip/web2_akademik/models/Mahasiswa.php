<!-- Models/Mahasiswa.PHP -->

<?php

require_once "config/database.php";

class Mahasiswa{

    public function getAll(){

        global $koneksi;

        $query = mysqli_query($koneksi, "SELECT * FROM mahasiswa");

        $data = [];

        while($row = mysqli_fetch_assoc($query)){
            $data[] = $row;
        }

        return $data;
    }


    public function insert($nim,$nama,$email){

        global $koneksi;

        mysqli_query($koneksi,
            "INSERT INTO mahasiswa(nim,nama,email)
            VALUES('$nim','$nama','$email')"
        );
    }


    /* ================= AMBIL DATA BERDASARKAN ID ================= */

    public function getById($id){

        global $koneksi;

        $query = mysqli_query($koneksi,
            "SELECT * FROM mahasiswa WHERE id='$id'"
        );

        return mysqli_fetch_assoc($query);
    }


    /* ================= UPDATE DATA ================= */

    public function update($id,$nim,$nama,$email){

        global $koneksi;

        mysqli_query($koneksi,
            "UPDATE mahasiswa SET
            nim='$nim',
            nama='$nama',
            email='$email'
            WHERE id='$id'"
        );
    }


    /* ================= HAPUS DATA ================= */

    public function delete($id){

        global $koneksi;

        mysqli_query($koneksi,
            "DELETE FROM mahasiswa WHERE id='$id'"
        );
    }

}
?>