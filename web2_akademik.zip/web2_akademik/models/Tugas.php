<!-- Models/Tugas.PHP -->

<?php

require_once "config/database.php";

class Tugas{

    public function getAll(){

        global $koneksi;

        $query = mysqli_query($koneksi, "SELECT * FROM tugas");

        $data = [];

        while($row = mysqli_fetch_assoc($query)){
            $data[] = $row;
        }

        return $data;
    }


    public function insert($judul,$deskripsi,$deadline){

        global $koneksi;

        mysqli_query($koneksi,
            "INSERT INTO tugas(judul,deskripsi,deadline)
            VALUES('$judul','$deskripsi','$deadline')"
        );
    }


    /* ================= AMBIL DATA BERDASARKAN ID ================= */

    public function getById($id){

        global $koneksi;

        $query = mysqli_query($koneksi,
            "SELECT * FROM tugas WHERE id='$id'"
        );

        return mysqli_fetch_assoc($query);
    }


    /* ================= UPDATE ================= */

    public function update($id,$judul,$deskripsi,$deadline){

        global $koneksi;

        mysqli_query($koneksi,
            "UPDATE tugas SET
            judul='$judul',
            deskripsi='$deskripsi',
            deadline='$deadline'
            WHERE id='$id'"
        );
    }


    /* ================= DELETE ================= */

    public function delete($id){

        global $koneksi;

        mysqli_query($koneksi,
            "DELETE FROM tugas WHERE id='$id'"
        );
    }

}
?>