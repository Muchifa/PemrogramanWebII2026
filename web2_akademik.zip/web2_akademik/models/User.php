<!-- Models/User.PHP -->

<?php
class User {

    private $db;

    public function __construct($koneksi) {
        $this->db = $koneksi;
    }

    // ================= LOGIN =================
    public function login($username, $password) {
        $q = mysqli_query($this->db,
            "SELECT * FROM users WHERE username='$username'"
        );

        if ($row = mysqli_fetch_assoc($q)) {
            if (password_verify($password, $row['password'])) {
                return $row;
            }
        }
        return false;
    }

    // ================= TAMPIL DATA =================
    public function db() {
        return mysqli_query($this->db, "SELECT * FROM users");
    }

    // ================= TAMBAH DATA =================
    public function insert($username, $password, $role) {
        $password = password_hash($password, PASSWORD_DEFAULT);

        return mysqli_query($this->db,
            "INSERT INTO users VALUES (
                NULL,
                '$username',
                '$password',
                '$role'
            )"
        );
    }

    // ================= CARI DATA =================
    public function find($id) {
        return mysqli_query($this->db,
            "SELECT * FROM users WHERE id='$id'"
        );
    }

    // ================= UPDATE DATA =================
    public function update($id, $username, $password, $role) {

        if (!empty($password)) {
            $password = password_hash($password, PASSWORD_DEFAULT);
            $query = "UPDATE users SET
                username='$username',
                password='$password',
                role='$role'
                WHERE id='$id'";
        } else {
            $query = "UPDATE users SET
                username='$username',
                password='$password',
                role='$role'
                WHERE id='$id'";
        }

        return mysqli_query($this->db, $query);
    }

    // ================= HAPUS DATA =================
    public function delete($id) {
        return mysqli_query($this->db,
            "DELETE FROM users WHERE id='$id'"
        );
    }
}