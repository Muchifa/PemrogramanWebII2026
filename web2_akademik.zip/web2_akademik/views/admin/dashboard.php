<?php include 'views/layout/header.php'; ?>
<?php include 'views/layout/navbar.php'; ?>

<h2>Dashboard</h2>
<p>Selamat Datang, Admin</p>