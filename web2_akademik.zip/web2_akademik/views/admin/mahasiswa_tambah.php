<?php include 'views/layout/header.php'; ?>
<?php include 'views/layout/navbar.php'; ?>

<div class="col-md-10 p-4">
    <h3>Tambah Mahasiswa</h3>

    <form method="post" action="index.php?page=simpan_mahasiswa">
        <input type="text" name="nim" class="form-control mb-2" placeholder="NIM" required>
        <input type="text" name="nama" class="form-control mb-2" placeholder="NAMA" required>
        <input type="email" name="email" class="form-control mb-3" placeholder="EMAIL" required>
        <button class="btn btn-success">Simpan</button>
        <a href="index.php?page=mahasiswa" class="btn btn-secondary">Kembali</a>
    </form>
</div>

<?php include 'views/layout/footer.php'; ?>