<?php require 'views/layout/header.php'; ?>
<?php require 'views/layout/navbar.php'; ?>

<h2>Data Tugas</h2>

<a href="index.php?page=tambah_tugas" class="btn btn-primary mb-3">
Tambah Tugas
</a>

<table class="table table-bordered">

<tr>
    <th>No</th>
    <th>Judul</th>
    <th>Deskripsi</th>
    <th>Deadline</th>
    <th>Aksi</th>
</tr>

<?php
$no = 1;

if(!empty($tugas)){
foreach($tugas as $t){
?>

<tr>
    <td><?php echo $no++; ?></td>
    <td><?php echo $t['judul']; ?></td>
    <td><?php echo $t['deskripsi']; ?></td>
    <td><?php echo $t['deadline']; ?></td>

    <td>
        <a href="index.php?page=edit_tugas&id=<?php echo $t['id']; ?>"
        class="btn btn-warning btn-sm">Edit</a>

        <a href="index.php?page=hapus_tugas&id=<?php echo $t['id']; ?>"
        class="btn btn-danger btn-sm"
        onclick="return confirm('Yakin hapus data?')">
        Hapus
        </a>
    </td>
</tr>

<?php
}}
?>

</table>

<?php require 'views/layout/footer.php'; ?>