<?php require 'views/layout/header.php'; ?>
<?php require 'views/layout/navbar.php'; ?>

<h2>Tambah Tugas</h2>

<form method="POST" action="index.php?page=simpan_tugas">

<div class="mb-3">
<label>Judul</label>
<input type="text" name="judul" class="form-control">
</div>

<div class="mb-3">
<label>Deskripsi</label>
<textarea name="deskripsi" class="form-control"></textarea>
</div>

<div class="mb-3">
<label>Deadline</label>
<input type="date" name="deadline" class="form-control">
</div>

<button class="btn btn-primary">Simpan</button>

<a href="index.php?page=tugas" class="btn btn-secondary">
Kembali
</a>

</form>

<?php require 'views/layout/footer.php'; ?>