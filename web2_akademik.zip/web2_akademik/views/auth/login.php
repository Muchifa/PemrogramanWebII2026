<?php
require_once "config/database.php";

/* jika sudah login langsung ke dashboard */
if(isset($_SESSION['login'])){
    header("Location: index.php?page=dashboard");
    exit;
}

if(isset($_POST['login'])){

    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = mysqli_query($koneksi,"SELECT * FROM users WHERE username='$username'");
    $user = mysqli_fetch_assoc($query);

    if($user){

        if(password_verify($password,$user['password'])){

            $_SESSION['login'] = true;
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];

            header("Location: index.php?page=dashboard");
            exit;

        }else{

            $error = "Password salah";

        }

    }else{

        $error = "Username tidak ditemukan";

    }
}
?>



<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5 col-md-4">
    <div class="card">
        <div class="card-body">
            <h4 class="mb-3">Login Sistem</h4>

            <?php if(isset($_GET['error'])): ?>
                <div class="alert alert-danger">Login gagal</div>
            <?php endif; ?>

            <form method="POST" action="index.php?page=login-proses">
                <input type="text" name="username" class="form-control mb-2" placeholder="Username" required>
                <input type="password" name="password" class="form-control mb-3" placeholder="Password" required>
                <button type="submit" class="btn btn-primary w-100">Login</button>
				<b>
				<a href="index.php?page=register">Belum Punya Akun? Register here</a>
            </form>
        </div>
    </div>
</div>

</body>
</html>   