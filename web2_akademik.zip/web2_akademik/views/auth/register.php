<?php require 'views/layout/header.php'; ?>

<?php require_once "config/database.php"; ?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap & Font Awesome -->
    <link rel="stylesheet" href="bootstrap.min.css">
    
    <link rel="stylesheet" href="css/all.min.css">
	
    <title>Register</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        footer {
        text-align: center;
        padding: 5px;
        background-color: #333;
        color: white;
        position: fixed;
        bottom: 0;
        width: 100%;
        height: 5%;
      }

      .container {
        width: 25%;
        margin-top: 9%;
        box-shadow: 0 3px 20px rgba(0,0,0,0.5);
        padding: 20px;
        border-radius: 8px;
      }

      .btn {
        width: 49%;
        padding: 5px;
      }
    </style>
</head>

<body background="A.&D._Chan.png">
    <div class="container">
      <h2 class="text-center">DAFTAR</h2>>


    <form method="POST" action="index.php?page=register-proses">

        <form id="formRegister">
        <div class="form-group">
          <label>USERNAME</label>
          <div class="input-group">
            <div class="input-group-prepend">
              <div class="input-group-text"><i class="fa fa-user"></i></div>
            </div>
            <input type="text" class="form-control" name="username" placeholder="Masukkan USERNAME" required />
          </div>
        </div>

        <div class="form-group">
          <label>PASSWORD</label>
          <div class="input-group">
            <div class="input-group-prepend">
              <div class="input-group-text"><i class="fa fa-unlock"></i></div>
            </div>
            <input type="password" class="form-control" name="password" placeholder="Masukkan Password" required />
          </div>
        </div>


            <button type="submit" class="btn btn-primary">DAFTAR</button>
            <button type="reset" class="btn btn-danger">RESET</button>

    </form>

    <div>
        <a>Sudah punya akun?</a>
        <a href="index.php?page=login" class="text-center">Login</a>
    </div>

</div>

</body>
</html>

<!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

<?php require 'views/layout/footer.php'; ?>