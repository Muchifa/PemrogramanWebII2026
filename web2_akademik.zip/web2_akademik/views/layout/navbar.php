<nav class="navbar navbar-dark bg-dark navbar-expand-lg">

<div class="container-fluid">

<a class="navbar-brand" href="#">WEB 2 MVC</a>

<ul class="navbar-nav me-auto">

<li class="nav-item">
<a class="nav-link" href="index.php?page=dashboard">Dashboard</a>
</li>

<li class="nav-item">
<a class="nav-link" href="index.php?page=mahasiswa">Mahasiswa</a>
</li>

<li class="nav-item">
<a class="nav-link" href="index.php?page=tugas">Tugas</a>
</li>

</ul>

<span class="text-white me-3">
<?php echo $_SESSION['username']; ?>
</span>

<a href="index.php?page=logout" class="btn btn-danger btn-sm">
Logout
</a>

</div>

</nav>

<div class="container mt-4">