<!-- DASHBOARD MAHASISWA -->

<?php require 'views/layout/header_mahasiswa.php'; ?>
<?php require 'views/layout/navbar_mahasiswa.php'; ?>

<h2>Dashboard Mahasiswa</h2>

<div class="alert alert-success">
Selamat datang, <?php echo $_SESSION['username']; ?>
</div>

<a href="index.php?page=lihat_tugas" class="btn btn-primary">
Lihat Tugas
</a>


<?php require 'views/layout/footer.php'; ?>