<!-- MAHASISWA TUGAS -->

<?php require 'views/layout/header_mahasiswa.php'; ?>
<?php require 'views/layout/navbar_mahasiswa.php'; ?>

<h2>Daftar Tugas</h2>

<table class="table table-bordered">
<tr>
<th>No</th>
<th>Judul</th>
<th>Deskripsi</th>
<th>Deadline</th>
<th>Aksi</th>
</tr>

<?php $no=1; foreach($tugas as $t){ ?>
<tr>
<td><?= $no++ ?></td>
<td><?= $t['judul'] ?></td>
<td><?= $t['deskripsi'] ?></td>
<td><?= $t['deadline'] ?></td>
<td>
<a href="index.php?page=upload_tugas&id=<?= $t['id'] ?>"
class="btn btn-success btn-sm">
Upload
</a>
</td>
</tr>
<?php } ?>

</table>

<?php require 'views/layout/footer.php'; ?>