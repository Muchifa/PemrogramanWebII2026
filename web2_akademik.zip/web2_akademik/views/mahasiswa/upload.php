<!-- MAHASISWA UPLOAD TUGAS -->

<?php require 'views/layout/header_mahasiswa.php'; ?>
<?php require 'views/layout/navbar_mahasiswa.php'; ?>

<h2>Upload Jawaban</h2>

<form method="POST" action="index.php?page=simpan_upload"
enctype="multipart/form-data">

<input type="file" name="file" class="form-control mb-3" required>

<button class="btn btn-primary">Upload</button>

</form>

<?php require 'views/layout/footer.php'; ?>